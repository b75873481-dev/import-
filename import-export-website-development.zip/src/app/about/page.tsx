import { Counter, MaskLines, Parallax, Reveal, SectionLabel, Tilt } from "@/components/motion/primitives";

const milestones = [
  { year: "2011", event: "Founded as a regional trading house connecting Latin American food producers to European buyers." },
  { year: "2015", event: "Expanded into industrial raw materials and opened a licensed customs brokerage desk." },
  { year: "2019", event: "Launched FDA and CE compliance programme for medical and healthcare exports." },
  { year: "2022", event: "Integrated SAP and Oracle ERP connectors for enterprise buyers." },
  { year: "2026", event: "Serving 62 countries with real-time tracking across sea, air and land freight." },
];

const values = [
  { title: "Compliance first", body: "Every transaction is structured to satisfy WTO, FDA, CE and ISO requirements before it leaves the warehouse.", icon: "🛡️" },
  { title: "Radical transparency", body: "Transparent pricing, live tracking and clear documentation — no hidden fees, no surprises.", icon: "🔍" },
  { title: "Security by default", body: "256-bit SSL encryption, PCI-DSS aligned payments and routine security patching protect every transaction.", icon: "🔐" },
  { title: "Built to integrate", body: "Native ERP and accounting connectors keep your systems and ours synchronised automatically.", icon: "🔗" },
];

const stats = [
  { to: 62, suffix: "", label: "Countries served" },
  { to: 2500, suffix: "+", label: "Active SKUs" },
  { to: 98.6, suffix: "%", decimals: 1, label: "On-time delivery" },
  { to: 15, suffix: "+", label: "Years operating" },
];

export default function AboutPage() {
  return (
    <div className="bg-ink">
      <section className="relative overflow-hidden border-b border-white/[0.07] bg-ink-2 pt-36 pb-20">
        <div className="pointer-events-none absolute inset-0 grid-bg opacity-45" />
        <div className="pointer-events-none absolute -left-32 top-10 h-[460px] w-[460px] rounded-full bg-lime/[0.1] blur-[130px]" />
        <div className="relative mx-auto max-w-[1400px] px-6">
          <SectionLabel index="01">About GlobexTrade</SectionLabel>
          <h1 className="font-display mt-6 max-w-5xl text-[clamp(2.3rem,6.4vw,5rem)] font-bold leading-[0.98] tracking-[-0.04em] text-bone">
            <MaskLines
              lines={[
                <span key="a">One platform for sourcing,</span>,
                <span key="b">
                  compliance <span className="text-lime">&amp; delivery.</span>
                </span>,
              ]}
            />
          </h1>
          <Reveal delay={0.2}>
            <p className="mt-7 max-w-2xl text-[15px] leading-relaxed text-mist">
              We connect verified manufacturers with businesses worldwide — combining a certified product catalog,
              secure payments and real-time logistics visibility inside a single accountable platform.
            </p>
          </Reveal>
        </div>
      </section>

      {/* stats */}
      <section className="border-b border-white/[0.07] bg-ink py-14">
        <div className="mx-auto grid max-w-[1400px] gap-px overflow-hidden px-6 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s, i) => (
            <Reveal key={s.label} delay={i * 0.08} className="px-2 py-6 text-center lg:border-r lg:border-white/[0.06] lg:last:border-0">
              <p className="font-display text-[clamp(2.2rem,5vw,3.2rem)] font-bold leading-none tracking-tight text-lime">
                <Counter to={s.to} decimals={s.decimals ?? 0} suffix={s.suffix} />
              </p>
              <p className="font-mono-gt mt-3 text-[10px] uppercase tracking-[0.24em] text-mist">{s.label}</p>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-6 py-20">
        <div className="grid gap-14 lg:grid-cols-[0.95fr_1.05fr] lg:items-start">
          <div className="lg:sticky lg:top-32">
            <SectionLabel index="02">Our story</SectionLabel>
            <h2 className="font-display mt-6 text-[clamp(1.9rem,4vw,3rem)] font-bold leading-[1.05] tracking-[-0.03em] text-bone">
              From a small sourcing desk to 62 countries.
            </h2>
            <Reveal delay={0.12}>
              <p className="mt-6 text-[15px] leading-relaxed text-mist">
                GlobexTrade Co. started as a small sourcing desk connecting coffee farmers to European roasters. Today
                we manage end-to-end import/export for food &amp; beverage, industrial materials, medical supplies,
                energy equipment and textiles — all under the same principle: one accountable team, from factory to
                final mile.
              </p>
              <p className="mt-4 text-[15px] leading-relaxed text-mist">
                Our in-house compliance specialists, licensed customs brokers and logistics coordinators work as a
                single team, so customers never chase multiple vendors or decode conflicting regulations.
              </p>
            </Reveal>
            <Reveal delay={0.2}>
              <Parallax distance={28} className="mt-8 rounded-[28px]">
                <div className="overflow-hidden rounded-[28px] border border-white/[0.08]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src="https://images.pexels.com/photos/17311127/pexels-photo-17311127.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
                    alt="Container port operations"
                    className="h-64 w-full scale-110 object-cover opacity-85"
                  />
                </div>
              </Parallax>
            </Reveal>
          </div>

          <div>
            <SectionLabel index="03">Milestones</SectionLabel>
            <ol className="relative mt-8 space-y-8 pl-8">
              <span className="absolute left-[7px] top-2 h-[calc(100%-16px)] w-px bg-gradient-to-b from-lime via-signal to-transparent" />
              {milestones.map((m, i) => (
                <Reveal key={m.year} delay={i * 0.08} y={26}>
                  <li className="relative">
                    <span className="absolute -left-8 top-1.5 flex h-[15px] w-[15px] items-center justify-center rounded-full border-2 border-lime bg-ink" />
                    <p className="font-display text-2xl font-bold tracking-tight text-lime">{m.year}</p>
                    <p className="mt-1.5 max-w-lg text-sm leading-relaxed text-mist">{m.event}</p>
                  </li>
                </Reveal>
              ))}
            </ol>
          </div>
        </div>
      </section>

      <section className="relative border-t border-white/[0.07] bg-ink-2 py-20">
        <div className="pointer-events-none absolute inset-0 dot-bg opacity-20" />
        <div className="relative mx-auto max-w-[1400px] px-6">
          <div className="text-center">
            <div className="flex justify-center">
              <SectionLabel index="04">Values</SectionLabel>
            </div>
            <h2 className="font-display mt-6 text-[clamp(1.9rem,4.2vw,3.2rem)] font-bold tracking-[-0.03em] text-bone">
              <MaskLines lines={[<span key="a">What we stand for.</span>]} />
            </h2>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((v, i) => (
              <Reveal key={v.title} delay={i * 0.08} y={36}>
                <Tilt className="h-full" max={8}>
                  <div className="flex h-full flex-col rounded-[26px] border border-white/[0.08] bg-ink p-7 transition-colors duration-500 group-hover/tilt:border-lime/35">
                    <span className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/[0.08] bg-ink-2 text-xl">
                      {v.icon}
                    </span>
                    <h3 className="font-display mt-5 text-base font-bold tracking-tight text-bone">{v.title}</h3>
                    <p className="mt-2.5 flex-1 text-sm leading-relaxed text-mist">{v.body}</p>
                  </div>
                </Tilt>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
