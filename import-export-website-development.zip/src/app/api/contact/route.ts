import { NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const { name, email, company, subject, message } = await request.json();

    if (!name || !email || !subject || !message) {
      return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
    }

    const [created] = await db
      .insert(contactMessages)
      .values({ name, email, company: company || null, subject, message })
      .returning();

    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error("Failed to save contact message", error);
    return NextResponse.json({ error: "Unable to send message." }, { status: 500 });
  }
}
