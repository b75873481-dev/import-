import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { generateOrderNumber } from "@/lib/format";

interface CartItemPayload {
  slug: string;
  name: string;
  price: number;
  currency: string;
  unit: string;
  quantity: number;
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      customerName,
      email,
      company,
      shippingAddress,
      paymentMethod,
      items,
      subtotal,
      total,
    }: {
      customerName: string;
      email: string;
      company?: string;
      shippingAddress: string;
      paymentMethod: string;
      items: CartItemPayload[];
      subtotal: number;
      total: number;
    } = body;

    if (!customerName || !email || !items?.length || !paymentMethod) {
      return NextResponse.json({ error: "Missing required order fields." }, { status: 400 });
    }

    const orderNumber = generateOrderNumber();
    const currency = items[0]?.currency ?? "USD";

    const [created] = await db
      .insert(orders)
      .values({
        orderNumber,
        customerName,
        email,
        company: company || null,
        items,
        subtotal: subtotal.toFixed(2),
        total: total.toFixed(2),
        currency,
        paymentMethod,
        paymentStatus: "paid",
        shippingAddress: shippingAddress || "N/A",
      })
      .returning();

    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error("Failed to create order", error);
    return NextResponse.json({ error: "Unable to process order." }, { status: 500 });
  }
}
