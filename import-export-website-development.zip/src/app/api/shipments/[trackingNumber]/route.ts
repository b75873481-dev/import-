import { NextResponse } from "next/server";
import { db } from "@/db";
import { shipments, shipmentEvents } from "@/db/schema";
import { eq, asc } from "drizzle-orm";

interface RouteContext {
  params: Promise<{ trackingNumber: string }>;
}

export async function GET(_request: Request, { params }: RouteContext) {
  const { trackingNumber } = await params;

  const [shipment] = await db
    .select()
    .from(shipments)
    .where(eq(shipments.trackingNumber, trackingNumber.toUpperCase()))
    .limit(1);

  if (!shipment) {
    return NextResponse.json({ error: "Shipment not found" }, { status: 404 });
  }

  const events = await db
    .select()
    .from(shipmentEvents)
    .where(eq(shipmentEvents.shipmentId, shipment.id))
    .orderBy(asc(shipmentEvents.occurredAt));

  return NextResponse.json({ shipment, events });
}
