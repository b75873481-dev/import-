import { NextResponse } from "next/server";
import { db } from "@/db";
import { shipments } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  const list = await db.select().from(shipments).orderBy(desc(shipments.createdAt));
  return NextResponse.json(list);
}
