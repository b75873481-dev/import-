"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { useCart } from "@/lib/cart-context";
import { formatCurrency } from "@/lib/format";
import { Magnetic, Reveal, SectionLabel } from "@/components/motion/primitives";

const EASE = [0.16, 1, 0.3, 1] as const;

export default function CartPage() {
  const { items, removeItem, updateQuantity, subtotal } = useCart();
  const freight = items.length > 0 ? 450 : 0;
  const total = subtotal + freight;

  return (
    <div className="min-h-screen bg-ink pt-32 pb-20">
      <div className="mx-auto max-w-[1200px] px-6">
        <SectionLabel index="01">Your order</SectionLabel>
        <h1 className="font-display mt-5 text-[clamp(2rem,5vw,3.4rem)] font-bold leading-[1.02] tracking-[-0.035em] text-bone">
          Order <span className="text-lime">cart.</span>
        </h1>
        <p className="mt-3 max-w-xl text-sm text-mist">
          Review your products before secure checkout. Freight and customs fees are estimated and confirmed during
          order processing.
        </p>

        {items.length === 0 ? (
          <Reveal y={30} className="mt-12">
            <div className="relative overflow-hidden rounded-[28px] border border-dashed border-white/15 bg-ink-2 p-20 text-center">
              <div className="pointer-events-none absolute inset-0 dot-bg opacity-20" />
              <motion.div
                animate={{ y: [0, -12, 0] }}
                transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut" }}
                className="relative mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-white/10 bg-ink text-2xl"
              >
                📦
              </motion.div>
              <p className="font-display relative mt-6 text-xl font-bold text-bone">Your cart is empty</p>
              <p className="relative mx-auto mt-2 max-w-sm text-sm text-mist">
                Browse our certified catalog of import/export products to get started.
              </p>
              <div className="relative mt-8">
                <Magnetic strength={0.28}>
                  <Link
                    href="/products"
                    className="group relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-lime px-7 py-3.5 text-sm font-bold text-ink"
                  >
                    <span className="relative z-10">Browse catalog</span>
                    <span className="relative z-10 transition-transform duration-500 group-hover:translate-x-1">→</span>
                    <span className="absolute inset-0 -translate-x-full bg-bone transition-transform duration-500 group-hover:translate-x-0" />
                  </Link>
                </Magnetic>
              </div>
            </div>
          </Reveal>
        ) : (
          <div className="mt-12 grid gap-6 lg:grid-cols-[1.55fr_1fr]">
            <div className="space-y-4">
              <AnimatePresence mode="popLayout">
                {items.map((item, i) => (
                  <motion.div
                    layout
                    key={item.slug}
                    initial={{ opacity: 0, y: 26 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -60, transition: { duration: 0.3 } }}
                    transition={{ duration: 0.5, delay: Math.min(i * 0.06, 0.3), ease: EASE }}
                    className="group flex gap-5 overflow-hidden rounded-[24px] border border-white/[0.08] bg-ink-2 p-4 transition-colors duration-500 hover:border-lime/30"
                  >
                    <div className="h-28 w-28 shrink-0 overflow-hidden rounded-2xl bg-ink-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="h-full w-full object-cover opacity-85 transition-transform duration-700 group-hover:scale-110"
                      />
                    </div>
                    <div className="flex min-w-0 flex-1 flex-col justify-between py-1">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <Link
                            href={`/products/${item.slug}`}
                            className="font-display block truncate text-sm font-bold text-bone transition-colors hover:text-lime"
                          >
                            {item.name}
                          </Link>
                          <p className="font-mono-gt mt-1 text-[10px] uppercase tracking-[0.16em] text-mist">
                            {formatCurrency(item.price, item.currency)} / {item.unit}
                          </p>
                        </div>
                        <button
                          onClick={() => removeItem(item.slug)}
                          className="font-mono-gt shrink-0 rounded-full border border-white/10 px-3 py-1 text-[9px] uppercase tracking-[0.16em] text-mist transition hover:border-red-400/50 hover:text-red-300"
                        >
                          Remove
                        </button>
                      </div>

                      <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateQuantity(item.slug, item.quantity - 1)}
                            className="flex h-9 w-9 items-center justify-center rounded-full border border-white/12 text-bone transition hover:border-lime hover:text-lime"
                            aria-label="Decrease"
                          >
                            −
                          </button>
                          <input
                            type="number"
                            value={item.quantity}
                            onChange={(e) => updateQuantity(item.slug, Number(e.target.value) || 1)}
                            className="font-mono-gt h-9 w-16 rounded-full border border-white/12 bg-ink/60 text-center text-sm tabular-nums text-bone focus:border-lime/50 focus:outline-none"
                            aria-label="Quantity"
                          />
                          <button
                            onClick={() => updateQuantity(item.slug, item.quantity + 1)}
                            className="flex h-9 w-9 items-center justify-center rounded-full border border-white/12 text-bone transition hover:border-lime hover:text-lime"
                            aria-label="Increase"
                          >
                            +
                          </button>
                        </div>
                        <motion.p
                          key={item.quantity}
                          initial={{ opacity: 0, y: 6 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="font-display text-base font-bold text-lime"
                        >
                          {formatCurrency(item.price * item.quantity, item.currency)}
                        </motion.p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <Reveal y={34} delay={0.12} className="lg:sticky lg:top-28 lg:self-start">
              <div className="relative overflow-hidden rounded-[26px] border border-white/[0.08] bg-ink-2 p-7">
                <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-lime/60 to-transparent" />
                <h2 className="font-display text-lg font-bold tracking-tight text-bone">Order summary</h2>
                <div className="mt-5 space-y-3 text-sm">
                  <Row label="Subtotal" value={formatCurrency(subtotal)} />
                  <Row label="Freight & customs (est.)" value={formatCurrency(freight)} />
                  <div className="border-t border-white/[0.08] pt-4">
                    <div className="flex items-baseline justify-between">
                      <span className="font-mono-gt text-[10px] uppercase tracking-[0.22em] text-mist">Estimated total</span>
                      <motion.span
                        key={total}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.3, ease: EASE }}
                        className="font-display text-2xl font-bold text-lime"
                      >
                        {formatCurrency(total)}
                      </motion.span>
                    </div>
                  </div>
                </div>
                <div className="mt-7">
                  <Magnetic strength={0.22}>
                    <Link
                      href="/checkout"
                      className="group relative block w-full overflow-hidden rounded-full bg-lime px-6 py-4 text-center text-sm font-bold text-ink"
                    >
                      <span className="relative z-10">Proceed to secure checkout</span>
                      <span className="absolute inset-0 -translate-x-full bg-bone transition-transform duration-500 group-hover:translate-x-0" />
                    </Link>
                  </Magnetic>
                </div>
                <p className="font-mono-gt mt-4 text-center text-[9px] uppercase tracking-[0.2em] text-mist">
                  🔒 256-bit SSL encrypted · PCI-DSS gateway
                </p>
              </div>
            </Reveal>
          </div>
        )}
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-mist">{label}</span>
      <span className="font-medium text-bone">{value}</span>
    </div>
  );
}
