"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { useCart } from "@/lib/cart-context";
import { formatCurrency } from "@/lib/format";
import { Magnetic, Reveal, SectionLabel } from "@/components/motion/primitives";

const EASE = [0.16, 1, 0.3, 1] as const;

const paymentMethods = [
  { id: "card", label: "Credit / Debit Card", icon: "💳", description: "Visa, Mastercard, Amex — PCI-DSS compliant gateway." },
  { id: "wire", label: "Bank Wire Transfer", icon: "🏦", description: "SWIFT wire transfer, ideal for large B2B orders." },
  { id: "escrow", label: "Escrow / Trade Finance", icon: "🔐", description: "Funds held in escrow until shipment is confirmed." },
  { id: "lc", label: "Letter of Credit (L/C)", icon: "📄", description: "Bank-guaranteed payment for international trade." },
];

const STEPS = ["Cart", "Details", "Payment", "Confirmed"];

export default function CheckoutPage() {
  const { items, subtotal, clearCart } = useCart();
  const router = useRouter();
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [destination, setDestination] = useState("");
  const [form, setForm] = useState({ name: "", email: "", company: "", address: "" });

  const freight = items.length > 0 ? 450 : 0;
  const total = subtotal + freight;

  function update(key: keyof typeof form, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (items.length === 0) return;
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: form.name,
          email: form.email,
          company: form.company,
          shippingAddress: `${form.address}${destination ? `, ${destination}` : ""}`,
          paymentMethod,
          items,
          subtotal,
          total,
        }),
      });
      if (!res.ok) throw new Error("Order could not be placed");
      const data = await res.json();
      clearCart();
      router.push(`/order-confirmation/${data.orderNumber}`);
    } catch {
      setError("Something went wrong placing your order. Please try again.");
      setSubmitting(false);
    }
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-6 py-40 text-center">
        <h1 className="font-display text-2xl font-bold text-bone">Your cart is empty</h1>
        <Link
          href="/products"
          className="mt-6 inline-block rounded-full bg-lime px-7 py-3.5 text-sm font-bold text-ink transition hover:bg-bone"
        >
          Browse products
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-ink pt-32 pb-20">
      <div className="mx-auto max-w-[1200px] px-6">
        <SectionLabel index="02">Secure checkout</SectionLabel>
        <h1 className="font-display mt-5 text-[clamp(2rem,5vw,3.4rem)] font-bold leading-[1.02] tracking-[-0.035em] text-bone">
          Complete your <span className="text-lime">order.</span>
        </h1>
        <p className="font-mono-gt mt-4 flex items-center gap-2 text-[10px] uppercase tracking-[0.22em] text-mist">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime gt-blink" />
          256-bit SSL encrypted · your data is never shared with third parties
        </p>

        {/* steps */}
        <div className="mt-8 flex flex-wrap items-center gap-3">
          {STEPS.map((s, i) => {
            const state = i < 2 ? "done" : i === 2 ? "active" : "todo";
            return (
              <div key={s} className="flex items-center gap-3">
                <span
                  className={`font-mono-gt flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[9px] uppercase tracking-[0.18em] ${
                    state === "done"
                      ? "border-lime/35 bg-lime/10 text-lime"
                      : state === "active"
                        ? "border-lime bg-lime text-ink"
                        : "border-white/10 text-mist"
                  }`}
                >
                  {i + 1}. {s}
                </span>
                {i < STEPS.length - 1 && <span className="h-px w-6 bg-white/12" />}
              </div>
            );
          })}
        </div>

        <form onSubmit={handleSubmit} className="mt-10 grid gap-6 lg:grid-cols-[1.5fr_1fr]">
          <div className="space-y-6">
            <Reveal y={30}>
              <div className="relative overflow-hidden rounded-[26px] border border-white/[0.08] bg-ink-2 p-7">
                <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-lime/50 to-transparent" />
                <h2 className="font-display text-lg font-bold tracking-tight text-bone">Billing &amp; shipping</h2>
                <div className="mt-6 grid gap-5 sm:grid-cols-2">
                  <Field label="Full name" required value={form.name} onChange={(v) => update("name", v)} />
                  <Field label="Email address" type="email" required value={form.email} onChange={(v) => update("email", v)} />
                  <Field label="Company name" value={form.company} onChange={(v) => update("company", v)} />
                  <Field label="Destination country" required value={destination} onChange={setDestination} />
                </div>
                <div className="mt-5">
                  <label className="group block">
                    <span className="font-mono-gt text-[9px] uppercase tracking-[0.26em] text-mist transition-colors group-focus-within:text-lime">
                      Shipping address <span className="text-lime">*</span>
                    </span>
                    <span className="mt-2 block rounded-2xl border border-white/10 bg-ink/60 transition-colors duration-300 group-focus-within:border-lime/50">
                      <textarea
                        required
                        rows={3}
                        value={form.address}
                        onChange={(e) => update("address", e.target.value)}
                        className="w-full resize-none bg-transparent px-4 py-3 text-sm text-bone focus:outline-none"
                      />
                    </span>
                  </label>
                </div>
              </div>
            </Reveal>

            <Reveal y={30} delay={0.08}>
              <div className="relative overflow-hidden rounded-[26px] border border-white/[0.08] bg-ink-2 p-7">
                <h2 className="font-display text-lg font-bold tracking-tight text-bone">Payment method</h2>
                <div className="mt-6 grid gap-3 sm:grid-cols-2">
                  {paymentMethods.map((method, i) => {
                    const active = paymentMethod === method.id;
                    return (
                      <motion.button
                        type="button"
                        key={method.id}
                        onClick={() => setPaymentMethod(method.id)}
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: i * 0.05, ease: EASE }}
                        whileHover={{ y: -3 }}
                        className={`relative overflow-hidden rounded-[22px] border p-5 text-left transition-colors duration-400 ${
                          active ? "border-lime/60 bg-lime/[0.07]" : "border-white/[0.08] hover:border-lime/30"
                        }`}
                      >
                        {active && (
                          <motion.span
                            layoutId="payment-active"
                            className="absolute inset-0 rounded-[22px] border border-lime/40"
                            transition={{ type: "spring", stiffness: 380, damping: 32 }}
                          />
                        )}
                        <span className="relative text-xl">{method.icon}</span>
                        <p className="font-display relative mt-3 text-sm font-bold text-bone">{method.label}</p>
                        <p className="relative mt-1 text-xs leading-relaxed text-mist">{method.description}</p>
                        {active && (
                          <span className="font-mono-gt absolute right-4 top-4 text-[9px] uppercase tracking-[0.18em] text-lime">
                            ● Selected
                          </span>
                        )}
                      </motion.button>
                    );
                  })}
                </div>

                <AnimatePresence>
                  {paymentMethod === "card" && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.4, ease: EASE }}
                      className="overflow-hidden"
                    >
                      <div className="mt-6 grid gap-5 sm:grid-cols-2">
                        <Field label="Card number" placeholder="4242 4242 4242 4242" required />
                        <Field label="Name on card" required />
                        <Field label="Expiry date" placeholder="MM / YY" required />
                        <Field label="CVC" placeholder="•••" required />
                      </div>
                    </motion.div>
                  )}
                  {paymentMethod !== "card" && (
                    <motion.p
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="font-mono-gt mt-5 text-[10px] uppercase leading-relaxed tracking-[0.16em] text-mist"
                    >
                      Payment instructions for {paymentMethods.find((m) => m.id === paymentMethod)?.label} will be
                      emailed after order confirmation.
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
            </Reveal>

            <AnimatePresence>
              {error && (
                <motion.p
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="rounded-2xl border border-amber/30 bg-amber/10 px-5 py-4 text-sm text-amber"
                >
                  {error}
                </motion.p>
              )}
            </AnimatePresence>

            <Magnetic strength={0.18}>
              <button
                type="submit"
                disabled={submitting}
                className="group relative w-full overflow-hidden rounded-full bg-lime px-6 py-4.5 text-sm font-bold text-ink disabled:opacity-60"
              >
                <span className="relative z-10 flex items-center justify-center gap-3 py-1">
                  {submitting ? (
                    <>
                      <motion.span
                        animate={{ rotate: 360 }}
                        transition={{ duration: 0.9, repeat: Infinity, ease: "linear" }}
                        className="inline-block h-4 w-4 rounded-full border-2 border-ink/30 border-t-ink"
                      />
                      Processing payment…
                    </>
                  ) : (
                    <>🔒 Pay {formatCurrency(total)} securely</>
                  )}
                </span>
                <span className="absolute inset-0 -translate-x-full bg-bone transition-transform duration-500 group-hover:translate-x-0" />
              </button>
            </Magnetic>
          </div>

          <Reveal y={34} delay={0.14} className="lg:sticky lg:top-28 lg:self-start">
            <div className="relative overflow-hidden rounded-[26px] border border-white/[0.08] bg-ink-2 p-7">
              <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-lime/60 to-transparent" />
              <h2 className="font-display text-lg font-bold tracking-tight text-bone">Order summary</h2>
              <div className="mt-5 space-y-3">
                {items.map((item) => (
                  <div key={item.slug} className="flex items-start justify-between gap-3 text-sm">
                    <span className="line-clamp-2 text-mist">
                      {item.name} <span className="font-mono-gt text-[10px] text-lime">×{item.quantity}</span>
                    </span>
                    <span className="shrink-0 font-semibold text-bone">
                      {formatCurrency(item.price * item.quantity, item.currency)}
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-5 space-y-2.5 border-t border-white/[0.08] pt-5 text-sm">
                <div className="flex justify-between">
                  <span className="text-mist">Subtotal</span>
                  <span className="text-bone">{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-mist">Freight &amp; customs (est.)</span>
                  <span className="text-bone">{formatCurrency(freight)}</span>
                </div>
                <div className="flex items-baseline justify-between border-t border-white/[0.08] pt-4">
                  <span className="font-mono-gt text-[10px] uppercase tracking-[0.22em] text-mist">Total</span>
                  <motion.span
                    key={total}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="font-display text-2xl font-bold text-lime"
                  >
                    {formatCurrency(total)}
                  </motion.span>
                </div>
              </div>
              <div className="font-mono-gt mt-6 space-y-2 border-t border-white/[0.08] pt-5 text-[9px] uppercase tracking-[0.16em] text-mist">
                <p>✓ Documents auto-generated on confirm</p>
                <p>✓ Tracking number issued instantly</p>
                <p>✓ Synced to SAP / Oracle / Xero</p>
              </div>
            </div>
          </Reveal>
        </form>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required = false,
  placeholder,
}: {
  label: string;
  value?: string;
  onChange?: (v: string) => void;
  type?: string;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <label className="group block">
      <span className="font-mono-gt text-[9px] uppercase tracking-[0.26em] text-mist transition-colors group-focus-within:text-lime">
        {label} {required && <span className="text-lime">*</span>}
      </span>
      <span className="mt-2 block rounded-2xl border border-white/10 bg-ink/60 transition-colors duration-300 group-focus-within:border-lime/50">
        <input
          type={type}
          required={required}
          value={value}
          placeholder={placeholder}
          onChange={(e) => onChange?.(e.target.value)}
          className="w-full bg-transparent px-4 py-3 text-sm text-bone placeholder:text-mist/40 focus:outline-none"
        />
      </span>
    </label>
  );
}
