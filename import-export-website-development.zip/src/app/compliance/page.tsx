import Link from "next/link";
import { Magnetic, Marquee, MaskLines, Reveal, SectionLabel } from "@/components/motion/primitives";

const standards = [
  {
    code: "WTO",
    name: "World Trade Organization Rules",
    description:
      "All cross-border transactions are structured to align with WTO tariff schedules, rules of origin and anti-dumping regulations — ensuring fair, lawful trade across member states.",
    icon: "🌐",
    points: ["Tariff schedules", "Rules of origin", "Anti-dumping", "TBT / SPS agreements"],
  },
  {
    code: "FDA",
    name: "U.S. Food & Drug Administration",
    description:
      "Food, beverage, medical device and healthcare products shipped to the United States are registered and documented per FDA prior-notice, labeling and facility registration requirements.",
    icon: "🏛️",
    points: ["Prior notice filing", "Facility registration", "Labeling review", "510(k) for devices"],
  },
  {
    code: "CE",
    name: "CE Marking — European Union",
    description:
      "Applicable goods destined for the EU carry CE marking under relevant directives (MDR, LVD, EMC), confirming conformity with EU health, safety and environmental protection standards.",
    icon: "🇪🇺",
    points: ["MDR 2017/745", "LVD / EMC", "Technical file", "EU Declaration of Conformity"],
  },
  {
    code: "ISO",
    name: "ISO 9001 / 14001 / 22000 / 13485",
    description:
      "Our supplier network is audited against ISO quality, environmental, food-safety and medical-device management system standards, with certificates re-verified annually.",
    icon: "📋",
    points: ["Quality management", "Environmental", "Food safety", "Medical devices"],
  },
];

const process = [
  { step: "01", title: "Supplier verification", body: "Factories are audited for licensing, certifications and production capacity before onboarding." },
  { step: "02", title: "Product testing", body: "Independent lab testing and QC inspections confirm compliance with destination-market regulations." },
  { step: "03", title: "Documentation", body: "Certificates of origin, test reports, safety data sheets and declarations prepared per shipment." },
  { step: "04", title: "Customs filing", body: "Licensed brokers file accurate HS classifications and duty calculations to prevent delays or penalties." },
  { step: "05", title: "Ongoing monitoring", body: "Regulatory changes across WTO, FDA, CE and local authorities are tracked and applied to active shipments." },
];

export default function CompliancePage() {
  return (
    <div className="bg-ink">
      <section className="relative overflow-hidden border-b border-white/[0.07] bg-ink-2 pt-36 pb-20">
        <div className="pointer-events-none absolute inset-0 grid-bg opacity-45" />
        <div className="pointer-events-none absolute -right-24 top-0 h-[440px] w-[440px] rounded-full bg-signal/[0.1] blur-[130px]" />
        <div className="pointer-events-none absolute -left-24 bottom-0 h-[380px] w-[380px] rounded-full bg-lime/[0.09] blur-[120px]" />
        <div className="relative mx-auto max-w-[1400px] px-6">
          <SectionLabel index="01">Regulatory compliance</SectionLabel>
          <h1 className="font-display mt-6 max-w-4xl text-[clamp(2.3rem,6.4vw,4.8rem)] font-bold leading-[0.98] tracking-[-0.04em] text-bone">
            <MaskLines
              lines={[
                <span key="a">Built for international</span>,
                <span key="b">
                  trade regulation, <span className="text-lime">by design.</span>
                </span>,
              ]}
            />
          </h1>
          <Reveal delay={0.2}>
            <p className="mt-7 max-w-2xl text-[15px] leading-relaxed text-mist">
              Every product, shipment and transaction on GlobexTrade is managed to satisfy WTO trade rules, FDA import
              requirements, CE marking directives and recognised ISO quality standards — verified before cargo moves.
            </p>
          </Reveal>
        </div>
      </section>

      <div className="border-b border-white/[0.07] bg-ink py-4">
        <Marquee speed={40} reverse>
          <span className="font-display flex items-center gap-10 px-5 text-2xl font-bold uppercase tracking-tight text-white/20">
            {["WTO", "FDA", "CE MARKING", "ISO 9001", "HACCP", "GOTS", "OEKO-TEX", "IATF 16949", "BRCGS", "ASC"].map(
              (s) => (
                <span key={s} className="flex items-center gap-10 transition-colors hover:text-lime">
                  {s} <span className="text-lime">◆</span>
                </span>
              )
            )}
          </span>
        </Marquee>
      </div>

      <section className="mx-auto max-w-[1400px] px-6 py-20">
        <div className="grid gap-5 md:grid-cols-2">
          {standards.map((s, i) => (
            <Reveal key={s.code} delay={i * 0.08} y={40}>
              <div className="group relative h-full overflow-hidden rounded-[28px] border border-white/[0.08] bg-ink-2 p-8 transition-colors duration-500 hover:border-lime/35">
                <div className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-lime/0 blur-3xl transition-all duration-700 group-hover:bg-lime/[0.12]" />
                <div className="relative flex items-start gap-5">
                  <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-white/[0.08] bg-ink text-2xl transition-transform duration-500 group-hover:scale-110 group-hover:border-lime/40">
                    {s.icon}
                  </span>
                  <div>
                    <p className="font-mono-gt text-[10px] uppercase tracking-[0.3em] text-lime">{s.code}</p>
                    <h3 className="font-display mt-1.5 text-xl font-bold tracking-tight text-bone">{s.name}</h3>
                  </div>
                </div>
                <p className="relative mt-6 text-sm leading-relaxed text-mist">{s.description}</p>
                <div className="relative mt-6 flex flex-wrap gap-2">
                  {s.points.map((p) => (
                    <span
                      key={p}
                      className="font-mono-gt rounded-full border border-white/10 px-3 py-1.5 text-[9px] uppercase tracking-[0.14em] text-mist transition-colors group-hover:border-lime/25 group-hover:text-lime"
                    >
                      {p}
                    </span>
                  ))}
                </div>
                <span className="absolute inset-x-0 bottom-0 h-px scale-x-0 bg-lime transition-transform duration-700 group-hover:scale-x-100" />
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="relative border-y border-white/[0.07] bg-ink-2 py-20">
        <div className="mx-auto max-w-[1400px] px-6">
          <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
            <div className="lg:sticky lg:top-32 lg:self-start">
              <SectionLabel index="02">Process</SectionLabel>
              <h2 className="font-display mt-6 text-[clamp(1.9rem,4vw,3.1rem)] font-bold leading-[1.04] tracking-[-0.03em] text-bone">
                <MaskLines lines={[<span key="a">Our five-step</span>, <span key="b" className="text-lime">compliance pipeline.</span>]} />
              </h2>
            </div>
            <div className="space-y-3">
              {process.map((p, i) => (
                <Reveal key={p.step} delay={i * 0.07} y={30}>
                  <div className="group relative flex gap-6 overflow-hidden rounded-[26px] border border-white/[0.08] bg-ink p-7 transition-colors duration-500 hover:border-lime/30">
                    <span className="font-display text-2xl font-bold leading-none text-white/[0.14] transition-colors duration-500 group-hover:text-lime/50">
                      {p.step}
                    </span>
                    <div>
                      <h3 className="font-display text-lg font-bold tracking-tight text-bone">{p.title}</h3>
                      <p className="mt-2 text-sm leading-relaxed text-mist">{p.body}</p>
                    </div>
                    <span className="pointer-events-none absolute inset-y-0 -left-full w-full bg-gradient-to-r from-transparent via-lime/[0.05] to-transparent transition-all duration-1000 group-hover:left-full" />
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-6 py-20">
        <Reveal y={40}>
          <div className="relative overflow-hidden rounded-[32px] border border-lime/25 bg-lime/[0.06] p-10 text-center">
            <div className="pointer-events-none absolute inset-0 dot-bg opacity-30" />
            <h2 className="font-display relative text-2xl font-bold tracking-tight text-bone md:text-3xl">
              Need compliance documents for a specific market?
            </h2>
            <p className="relative mx-auto mt-4 max-w-xl text-sm leading-relaxed text-mist">
              Our licensed trade compliance team prepares certificates of origin, safety data sheets and customs
              declarations tailored to your destination country — typically within 48 hours.
            </p>
            <div className="relative mt-8">
              <Magnetic strength={0.3}>
                <Link
                  href="/contact"
                  className="group relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-lime px-8 py-4 text-sm font-bold text-ink"
                >
                  <span className="relative z-10">Request compliance support</span>
                  <span className="relative z-10 transition-transform duration-500 group-hover:translate-x-1">→</span>
                  <span className="absolute inset-0 -translate-x-full bg-bone transition-transform duration-500 group-hover:translate-x-0" />
                </Link>
              </Magnetic>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
