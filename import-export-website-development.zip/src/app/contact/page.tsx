"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Magnetic, MaskLines, Reveal, SectionLabel } from "@/components/motion/primitives";


const channels = [
  { icon: "📧", label: "Email", value: "contact@globextrade.com", href: "mailto:contact@globextrade.com" },
  { icon: "☎️", label: "Trade desk", value: "+1 (800) 555-0192", href: "tel:+18005550192" },
  { icon: "📍", label: "Headquarters", value: "One Harbor Plaza, Singapore 018956" },
  { icon: "🕐", label: "Availability", value: "24/7, every day of the year" },
];

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", company: "", subject: "", message: "" });
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");

  function update(key: keyof typeof form, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error();
      setStatus("done");
      setForm({ name: "", email: "", company: "", subject: "", message: "" });
    } catch {
      setStatus("error");
    }
  }

  return (
    <div className="bg-ink">
      <section className="relative overflow-hidden border-b border-white/[0.07] bg-ink-2 pt-36 pb-20">
        <div className="pointer-events-none absolute inset-0 grid-bg opacity-45" />
        <div className="pointer-events-none absolute -right-24 top-0 h-[420px] w-[420px] rounded-full bg-lime/[0.1] blur-[130px]" />
        <div className="relative mx-auto max-w-[1400px] px-6">
          <SectionLabel index="01">Contact</SectionLabel>
          <h1 className="font-display mt-6 max-w-4xl text-[clamp(2.3rem,6.4vw,4.8rem)] font-bold leading-[0.98] tracking-[-0.04em] text-bone">
            <MaskLines
              lines={[
                <span key="a">Ready to move smarter?</span>,
                <span key="b" className="text-lime">
                  Let&apos;s talk trade.
                </span>,
              ]}
            />
          </h1>
          <Reveal delay={0.2}>
            <p className="mt-7 max-w-xl text-[15px] leading-relaxed text-mist">
              Whether you need a product quote, compliance support or an ERP integration, our trade specialists respond
              within one business day.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-6 py-16">
        <div className="grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="space-y-4">
            {channels.map((c, i) => {
              const inner = (
                <>
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-white/[0.08] bg-ink text-xl transition-transform duration-500 group-hover:scale-110 group-hover:border-lime/40">
                    {c.icon}
                  </span>
                  <div className="min-w-0">
                    <p className="font-mono-gt text-[9px] uppercase tracking-[0.26em] text-mist">{c.label}</p>
                    <p className="mt-1 truncate text-sm font-semibold text-bone transition-colors group-hover:text-lime">
                      {c.value}
                    </p>
                  </div>
                  <span className="ml-auto text-mist opacity-0 transition-all duration-500 group-hover:translate-x-0 group-hover:opacity-100">
                    →
                  </span>
                </>
              );
              return (
                <Reveal key={c.label} delay={i * 0.07}>
                  {c.href ? (
                    <a
                      href={c.href}
                      className="group flex items-center gap-4 rounded-[24px] border border-white/[0.08] bg-ink-2 p-5 transition-colors duration-500 hover:border-lime/35"
                    >
                      {inner}
                    </a>
                  ) : (
                    <div className="group flex items-center gap-4 rounded-[24px] border border-white/[0.08] bg-ink-2 p-5 transition-colors duration-500 hover:border-lime/35">
                      {inner}
                    </div>
                  )}
                </Reveal>
              );
            })}

            <Reveal delay={0.3}>
              <div className="relative overflow-hidden rounded-[24px] border border-lime/25 bg-lime/[0.06] p-6">
                <div className="pointer-events-none absolute inset-0 dot-bg opacity-25" />
                <p className="font-mono-gt relative text-[9px] uppercase tracking-[0.26em] text-lime">Security</p>
                <p className="relative mt-3 text-sm leading-relaxed text-bone">
                  All messages and documents are transmitted over 256-bit SSL and handled under our ISO-aligned data
                  handling policy.
                </p>
              </div>
            </Reveal>
          </div>

          <Reveal y={40} delay={0.1}>
            <form
              onSubmit={handleSubmit}
              className="relative overflow-hidden rounded-[28px] border border-white/[0.08] bg-ink-2 p-8"
            >
              <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-lime/60 to-transparent" />
              <h2 className="font-display text-xl font-bold tracking-tight text-bone">Send an enquiry</h2>

              <div className="mt-7 grid gap-5 sm:grid-cols-2">
                <Field label="Full name" required value={form.name} onChange={(v) => update("name", v)} />
                <Field label="Email" type="email" required value={form.email} onChange={(v) => update("email", v)} />
                <Field label="Company" value={form.company} onChange={(v) => update("company", v)} />
                <Field label="Subject" required value={form.subject} onChange={(v) => update("subject", v)} />
              </div>

              <div className="mt-5">
                <FieldArea label="Message" required value={form.message} onChange={(v) => update("message", v)} />
              </div>

              <div className="mt-7">
                <Magnetic strength={0.22}>
                  <button
                    type="submit"
                    disabled={status === "loading"}
                    className="group relative w-full overflow-hidden rounded-full bg-lime px-6 py-4 text-sm font-bold text-ink disabled:opacity-60"
                  >
                    <span className="relative z-10">
                      {status === "loading" ? "Transmitting…" : "Send message"}
                    </span>
                    <span className="absolute inset-0 -translate-x-full bg-bone transition-transform duration-500 group-hover:translate-x-0" />
                  </button>
                </Magnetic>
              </div>

              <AnimatePresence>
                {status === "done" && (
                  <motion.p
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="mt-4 text-center text-sm text-lime"
                  >
                    ✓ Message received. Our team will reach out shortly.
                  </motion.p>
                )}
                {status === "error" && (
                  <motion.p
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="mt-4 text-center text-sm text-amber"
                  >
                    Something went wrong. Please try again.
                  </motion.p>
                )}
              </AnimatePresence>
            </form>
          </Reveal>
        </div>
      </section>
    </div>
  );
}

function Shell({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <label className="group block">
      <span className="font-mono-gt text-[9px] uppercase tracking-[0.26em] text-mist transition-colors group-focus-within:text-lime">
        {label} {required && <span className="text-lime">*</span>}
      </span>
      <span className="mt-2 block rounded-2xl border border-white/10 bg-ink/60 transition-colors duration-300 group-focus-within:border-lime/50">
        {children}
      </span>
    </label>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <Shell label={label} required={required}>
      <input
        type={type}
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-transparent px-4 py-3 text-sm text-bone placeholder:text-mist/50 focus:outline-none"
      />
    </Shell>
  );
}

function FieldArea({
  label,
  value,
  onChange,
  required = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <Shell label={label} required={required}>
      <textarea
        required={required}
        rows={5}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full resize-none bg-transparent px-4 py-3 text-sm text-bone placeholder:text-mist/50 focus:outline-none"
      />
    </Shell>
  );
}

