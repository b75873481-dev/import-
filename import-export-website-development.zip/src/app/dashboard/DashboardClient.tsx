"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import Link from "next/link";
import { formatDate } from "@/lib/format";
import { Counter, SectionLabel } from "@/components/motion/primitives";

interface Shipment {
  id: number;
  trackingNumber: string;
  status: string;
  mode: string;
  originPort: string;
  destinationPort: string;
  customerName: string;
  productSummary: string;
  customsStatus: string;
  eta: string;
}

export interface Kpi {
  id: string;
  label: string;
  value: number;
  display: string;
  decimals: number;
  sub: string;
  icon: string;
}

const STORAGE_KEY = "globex-dashboard-widgets";
const EASE = [0.16, 1, 0.3, 1] as const;

const SPARK = [38, 44, 41, 52, 58, 54, 66, 72, 68, 79, 86, 94];

function statusTone(status: string) {
  const s = status.toLowerCase();
  if (s.includes("deliver")) return "border-lime/30 bg-lime/10 text-lime";
  if (s.includes("customs")) return "border-amber/30 bg-amber/10 text-amber";
  if (s.includes("transit") || s.includes("depart") || s.includes("loaded"))
    return "border-signal/30 bg-signal/10 text-signal";
  return "border-white/12 bg-white/5 text-mist";
}

export function DashboardClient({
  shipments,
  kpis,
  productCount,
  orderCount,
}: {
  shipments: Shipment[];
  kpis: Kpi[];
  productCount: number;
  orderCount: number;
}) {
  const reduce = useReducedMotion();
  const [visible, setVisible] = useState<Record<string, boolean> | null>(null);
  const [modeFilter, setModeFilter] = useState("all");
  const [configOpen, setConfigOpen] = useState(false);
  const [pulse, setPulse] = useState(0);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) setVisible(JSON.parse(stored));
      else setVisible(Object.fromEntries(kpis.map((k) => [k.id, true])));
    } catch {
      setVisible(Object.fromEntries(kpis.map((k) => [k.id, true])));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!visible) return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(visible));
  }, [visible]);

  useEffect(() => {
    const id = setInterval(() => setPulse((p) => p + 1), 5000);
    return () => clearInterval(id);
  }, []);

  const filtered = useMemo(
    () => (modeFilter === "all" ? shipments : shipments.filter((s) => s.mode === modeFilter)),
    [shipments, modeFilter]
  );

  const statusBreakdown = useMemo(() => {
    const counts: Record<string, number> = {};
    shipments.forEach((s) => (counts[s.status] = (counts[s.status] ?? 0) + 1));
    return Object.entries(counts).sort((a, b) => b[1] - a[1]);
  }, [shipments]);

  const modeBreakdown = useMemo(() => {
    const counts: Record<string, number> = {};
    shipments.forEach((s) => (counts[s.mode] = (counts[s.mode] ?? 0) + 1));
    return Object.entries(counts);
  }, [shipments]);

  const integrations = [
    { name: "SAP S/4HANA", type: "ERP", state: "connected" },
    { name: "Oracle NetSuite", type: "ERP", state: "connected" },
    { name: "Microsoft Dynamics", type: "ERP", state: "available" },
    { name: "QuickBooks", type: "Accounting", state: "pending" },
    { name: "Xero", type: "Accounting", state: "connected" },
  ];

  const sparkPath = useMemo(() => {
    const w = 100;
    const h = 34;
    const max = Math.max(...SPARK);
    return SPARK.map((v, i) => `${i === 0 ? "M" : "L"} ${(i / (SPARK.length - 1)) * w} ${h - (v / max) * h}`).join(" ");
  }, []);

  return (
    <div className="min-h-screen bg-ink pt-32 pb-20">
      <div className="mx-auto max-w-[1400px] px-6">
        {/* header */}
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <SectionLabel index="01">Trade operations</SectionLabel>
            <h1 className="font-display mt-5 text-[clamp(2rem,5vw,3.4rem)] font-bold leading-[1.02] tracking-[-0.035em] text-bone">
              Command <span className="text-lime">centre.</span>
            </h1>
            <p className="mt-3 max-w-lg text-sm text-mist">
              Monitor KPIs, shipment status and customs clearance in one customizable view — synced live with your ERP.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-mono-gt flex items-center gap-2 rounded-full border border-lime/25 bg-lime/[0.07] px-4 py-2 text-[10px] uppercase tracking-[0.2em] text-lime">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime gt-blink" />
              Synced · {String(pulse).padStart(4, "0")}
            </span>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setConfigOpen((v) => !v)}
              className={`rounded-full border px-5 py-2.5 text-xs font-semibold transition ${
                configOpen
                  ? "border-lime bg-lime text-ink"
                  : "border-white/15 text-bone hover:border-lime hover:text-lime"
              }`}
            >
              {configOpen ? "Done" : "Customize KPIs"}
            </motion.button>
          </div>
        </div>

        {/* KPI config */}
        <AnimatePresence>
          {configOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.45, ease: EASE }}
              className="overflow-hidden"
            >
              <div className="mt-6 flex flex-wrap gap-2.5 rounded-[24px] border border-white/[0.08] bg-ink-2 p-5">
                {kpis.map((k) => {
                  const on = visible?.[k.id] ?? true;
                  return (
                    <button
                      key={k.id}
                      onClick={() => setVisible((v) => ({ ...(v ?? {}), [k.id]: !on }))}
                      className={`flex items-center gap-2 rounded-full border px-4 py-2 text-xs font-medium transition ${
                        on
                          ? "border-lime/40 bg-lime/10 text-lime"
                          : "border-white/10 text-mist hover:border-white/25"
                      }`}
                    >
                      <span className={`h-2 w-2 rounded-full ${on ? "bg-lime" : "bg-white/20"}`} />
                      {k.label}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* KPI grid */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <AnimatePresence mode="popLayout">
            {kpis
              .filter((k) => visible?.[k.id] ?? true)
              .map((k, i) => (
                <motion.div
                  layout
                  key={k.id}
                  initial={{ opacity: 0, y: 24, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.92 }}
                  transition={{ duration: 0.5, delay: i * 0.05, ease: EASE }}
                  whileHover={{ y: -6 }}
                  className="group relative overflow-hidden rounded-[24px] border border-white/[0.08] bg-ink-2 p-6"
                >
                  <div className="pointer-events-none absolute -right-14 -top-14 h-32 w-32 rounded-full bg-lime/0 blur-2xl transition-all duration-700 group-hover:bg-lime/[0.14]" />
                  <div className="relative flex items-start justify-between">
                    <span className="text-xl">{k.icon}</span>
                    <span className="font-mono-gt rounded-full border border-lime/25 px-2 py-0.5 text-[9px] uppercase tracking-[0.16em] text-lime">
                      {k.sub}
                    </span>
                  </div>
                  <p className="font-display relative mt-5 text-[2rem] font-bold leading-none tracking-tight text-bone">
                    {k.decimals > 0 || k.value > 999 ? (
                      <Counter to={k.value} decimals={k.decimals} />
                    ) : (
                      k.display
                    )}
                  </p>
                  <p className="font-mono-gt relative mt-2 text-[9px] uppercase tracking-[0.22em] text-mist">
                    {k.label}
                  </p>
                  <span className="absolute inset-x-0 bottom-0 h-px scale-x-0 bg-lime transition-transform duration-700 group-hover:scale-x-100" />
                </motion.div>
              ))}
          </AnimatePresence>
        </div>

        {/* charts row */}
        <div className="mt-6 grid gap-4 lg:grid-cols-[1.5fr_1fr_1fr]">
          {/* volume sparkline */}
          <motion.div
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.65, ease: EASE }}
            className="rounded-[24px] border border-white/[0.08] bg-ink-2 p-6"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="font-mono-gt text-[9px] uppercase tracking-[0.24em] text-mist">Shipping volume</p>
                <p className="font-display mt-2 text-3xl font-bold tracking-tight text-bone">
                  <Counter to={3412} /> <span className="text-sm font-medium text-mist">orders / yr</span>
                </p>
              </div>
              <span className="font-mono-gt rounded-full border border-lime/25 bg-lime/10 px-2.5 py-1 text-[9px] uppercase tracking-[0.16em] text-lime">
                ▲ 18.4%
              </span>
            </div>
            <svg viewBox="0 0 100 34" preserveAspectRatio="none" className="mt-6 h-24 w-full">
              <defs>
                <linearGradient id="sparkFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#c8ff3e" stopOpacity="0.32" />
                  <stop offset="100%" stopColor="#c8ff3e" stopOpacity="0" />
                </linearGradient>
              </defs>
              <motion.path
                d={`${sparkPath} L 100 34 L 0 34 Z`}
                fill="url(#sparkFill)"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 1, delay: 0.4 }}
              />
              <motion.path
                d={sparkPath}
                fill="none"
                stroke="#c8ff3e"
                strokeWidth="1.4"
                strokeLinecap="round"
                vectorEffect="non-scaling-stroke"
                initial={{ pathLength: 0 }}
                whileInView={{ pathLength: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 1.8, ease: EASE }}
              />
            </svg>
            <div className="font-mono-gt mt-2 flex justify-between text-[9px] uppercase tracking-[0.18em] text-mist">
              {["Jan", "Mar", "May", "Jul", "Sep", "Nov"].map((m) => (
                <span key={m}>{m}</span>
              ))}
            </div>
          </motion.div>

          {/* mode bars */}
          <motion.div
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.65, delay: 0.08, ease: EASE }}
            className="rounded-[24px] border border-white/[0.08] bg-ink-2 p-6"
          >
            <p className="font-mono-gt text-[9px] uppercase tracking-[0.24em] text-mist">Freight mode mix</p>
            <div className="mt-6 space-y-4">
              {modeBreakdown.map(([mode, count], i) => (
                <div key={mode}>
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-bone">{mode}</span>
                    <span className="font-mono-gt text-mist">{count}</span>
                  </div>
                  <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/[0.06]">
                    <motion.div
                      className="h-full rounded-full bg-gradient-to-r from-lime to-signal"
                      initial={{ width: 0 }}
                      whileInView={{ width: `${(count / shipments.length) * 100}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1.1, delay: 0.2 + i * 0.12, ease: EASE }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* compliance donut */}
          <motion.div
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.65, delay: 0.16, ease: EASE }}
            className="rounded-[24px] border border-white/[0.08] bg-ink-2 p-6"
          >
            <p className="font-mono-gt text-[9px] uppercase tracking-[0.24em] text-mist">Compliance pass rate</p>
            <div className="mt-4 flex items-center gap-5">
              <div className="relative h-24 w-24 shrink-0">
                <svg viewBox="0 0 36 36" className="h-full w-full -rotate-90">
                  <circle cx="18" cy="18" r="15.5" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="3" />
                  <motion.circle
                    cx="18"
                    cy="18"
                    r="15.5"
                    fill="none"
                    stroke="#c8ff3e"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeDasharray="97.4"
                    initial={{ strokeDashoffset: 97.4 }}
                    whileInView={{ strokeDashoffset: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.6, ease: EASE, delay: 0.3 }}
                  />
                </svg>
                {!reduce && (
                  <span className="gt-spin-slow absolute inset-0 rounded-full border border-dashed border-lime/20" />
                )}
                <span className="font-display absolute inset-0 flex items-center justify-center text-sm font-bold text-bone">
                  100%
                </span>
              </div>
              <div className="space-y-1.5">
                {["WTO", "FDA", "CE", "ISO"].map((c) => (
                  <p key={c} className="font-mono-gt flex items-center gap-2 text-[10px] uppercase tracking-[0.16em] text-mist">
                    <span className="h-1.5 w-1.5 rounded-full bg-lime" /> {c} cleared
                  </p>
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* shipments + sidebar */}
        <div className="mt-6 grid gap-4 lg:grid-cols-[1.6fr_1fr]">
          <motion.div
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.65, ease: EASE }}
            className="rounded-[24px] border border-white/[0.08] bg-ink-2 p-6"
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="font-display text-lg font-bold tracking-tight text-bone">Active shipments</h2>
              <div className="flex gap-1.5">
                {["all", "Sea", "Air", "Land"].map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setModeFilter(mode)}
                    className={`relative rounded-full px-3.5 py-1.5 text-[11px] font-medium transition ${
                      modeFilter === mode ? "text-ink" : "border border-white/10 text-mist hover:text-bone"
                    }`}
                  >
                    {modeFilter === mode && (
                      <motion.span
                        layoutId="mode-pill"
                        className="absolute inset-0 rounded-full bg-lime"
                        transition={{ type: "spring", stiffness: 420, damping: 32 }}
                      />
                    )}
                    <span className="relative">{mode === "all" ? "All" : mode}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5 overflow-x-auto">
              <table className="w-full min-w-[680px] text-left">
                <thead>
                  <tr className="font-mono-gt border-b border-white/[0.08] text-[9px] uppercase tracking-[0.22em] text-mist">
                    <th className="pb-3 pr-4 font-normal">Ref</th>
                    <th className="pb-3 pr-4 font-normal">Customer</th>
                    <th className="pb-3 pr-4 font-normal">Mode</th>
                    <th className="pb-3 pr-4 font-normal">Status</th>
                    <th className="pb-3 pr-4 font-normal">Customs</th>
                    <th className="pb-3 text-right font-normal">ETA</th>
                  </tr>
                </thead>
                <tbody>
                  <AnimatePresence mode="popLayout">
                    {filtered.map((s, i) => (
                      <motion.tr
                        layout
                        key={s.id}
                        initial={{ opacity: 0, y: 14 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.45, delay: Math.min(i * 0.05, 0.3), ease: EASE }}
                        className="border-b border-white/[0.05] text-[13px] transition-colors last:border-0 hover:bg-white/[0.03]"
                      >
                        <td className="py-3.5 pr-4">
                          <Link href="/tracking" className="font-mono-gt text-[11px] text-lime hover:underline">
                            {s.trackingNumber}
                          </Link>
                        </td>
                        <td className="py-3.5 pr-4 text-bone">{s.customerName}</td>
                        <td className="py-3.5 pr-4 text-mist">{s.mode}</td>
                        <td className="py-3.5 pr-4">
                          <span className={`rounded-full border px-2.5 py-1 text-[10px] font-medium ${statusTone(s.status)}`}>
                            {s.status}
                          </span>
                        </td>
                        <td className="font-mono-gt py-3.5 pr-4 text-[10px] uppercase tracking-[0.12em] text-mist">
                          {s.customsStatus}
                        </td>
                        <td className="font-mono-gt py-3.5 text-right text-[11px] tabular-nums text-mist">
                          {formatDate(s.eta)}
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          </motion.div>

          <div className="space-y-4">
            <motion.div
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.65, delay: 0.08, ease: EASE }}
              className="rounded-[24px] border border-white/[0.08] bg-ink-2 p-6"
            >
              <h2 className="font-display text-lg font-bold tracking-tight text-bone">Status breakdown</h2>
              <div className="mt-5 space-y-3.5">
                {statusBreakdown.map(([status, count], i) => (
                  <div key={status}>
                    <div className="font-mono-gt flex justify-between text-[10px] uppercase tracking-[0.14em] text-mist">
                      <span className="truncate pr-2">{status}</span>
                      <span className="text-bone">{count}</span>
                    </div>
                    <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
                      <motion.div
                        className="h-full rounded-full bg-lime"
                        initial={{ width: 0 }}
                        whileInView={{ width: `${(count / shipments.length) * 100}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: 0.2 + i * 0.1, ease: EASE }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.65, delay: 0.16, ease: EASE }}
              className="rounded-[24px] border border-white/[0.08] bg-ink-2 p-6"
            >
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-bold tracking-tight text-bone">Integrations</h2>
                <span className="font-mono-gt text-[9px] uppercase tracking-[0.2em] text-mist">
                  {productCount} SKUs · {orderCount} orders
                </span>
              </div>
              <ul className="mt-5 space-y-3">
                {integrations.map((it, i) => (
                  <motion.li
                    key={it.name}
                    initial={{ opacity: 0, x: 16 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.45, delay: i * 0.07, ease: EASE }}
                    className="flex items-center justify-between rounded-2xl border border-white/[0.06] bg-ink/50 px-4 py-3"
                  >
                    <div>
                      <p className="text-sm font-semibold text-bone">{it.name}</p>
                      <p className="font-mono-gt text-[9px] uppercase tracking-[0.2em] text-mist">{it.type}</p>
                    </div>
                    <span
                      className={`font-mono-gt rounded-full border px-2.5 py-1 text-[9px] uppercase tracking-[0.14em] ${
                        it.state === "connected"
                          ? "border-lime/30 bg-lime/10 text-lime"
                          : it.state === "pending"
                            ? "border-amber/30 bg-amber/10 text-amber"
                            : "border-white/12 bg-white/5 text-mist"
                      }`}
                    >
                      {it.state === "connected" ? "● Live" : it.state === "pending" ? "◐ Pending" : "○ Ready"}
                    </span>
                  </motion.li>
                ))}
              </ul>
              <p className="font-mono-gt mt-4 text-[9px] uppercase leading-relaxed tracking-[0.16em] text-mist">
                Inventory &amp; orders sync automatically with connected systems every 5 minutes.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
