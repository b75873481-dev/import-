import { db } from "@/db";
import { orders, products, shipments } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import { DashboardClient, type Kpi } from "./DashboardClient";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const shipmentList = await db.select().from(shipments).orderBy(desc(shipments.createdAt));
  const [{ count: productCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(products);
  const [{ count: orderCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(orders);

  const inTransit = shipmentList.filter((s) => s.status.startsWith("In Transit")).length;
  const inCustoms = shipmentList.filter((s) => s.status.toLowerCase().includes("customs")).length;
  const delivered = shipmentList.filter((s) => s.status === "Delivered").length;

  const kpis: Kpi[] = [
    { id: "active", label: "Active shipments", value: shipmentList.length, display: String(shipmentList.length), decimals: 0, sub: "Live", icon: "🚢" },
    { id: "transit", label: "In transit", value: inTransit, display: String(inTransit), decimals: 0, sub: "On schedule", icon: "🛰️" },
    { id: "customs", label: "In customs clearance", value: inCustoms, display: String(inCustoms), decimals: 0, sub: "Monitored", icon: "🛃" },
    { id: "delivered", label: "Delivered this period", value: delivered, display: String(delivered), decimals: 0, sub: "Completed", icon: "✅" },
    { id: "products", label: "Active SKUs", value: productCount, display: String(productCount), decimals: 0, sub: "Catalog", icon: "📦" },
    { id: "orders", label: "Orders processed", value: orderCount, display: String(orderCount), decimals: 0, sub: "ERP synced", icon: "🧾" },
    { id: "ontime", label: "On-time delivery", value: 98.6, display: "98.6%", decimals: 1, sub: "Trailing 90d", icon: "⏱️" },
    { id: "compliance", label: "Compliance pass rate", value: 100, display: "100%", decimals: 0, sub: "WTO/FDA/CE", icon: "🛡️" },
  ];

  return (
    <DashboardClient
      shipments={shipmentList.map((s) => ({ ...s, eta: s.eta.toISOString() }))}
      kpis={kpis}
      productCount={productCount}
      orderCount={orderCount}
    />
  );
}
