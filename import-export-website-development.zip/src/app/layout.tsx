import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { LanguageProvider } from "@/i18n/LanguageProvider";
import { CartProvider } from "@/lib/cart-context";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import {
  Preloader,
  ScrollProgress,
  CustomCursor,
} from "@/components/motion/primitives";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk",
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
  display: "swap",
});

export const metadata: Metadata = {
  title: "GlobexTrade Co. | Certified Global Import & Export",
  description:
    "GlobexTrade Co. sources, certifies, and ships high-quality import/export products compliant with WTO, FDA, and CE regulations — with real-time tracking, secure payments and ERP integration.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${spaceGrotesk.variable} ${jetbrains.variable}`}
    >
      <body className="grain bg-ink text-bone antialiased">
        <LanguageProvider>
          <CartProvider>
            <Preloader />
            <ScrollProgress />
            <CustomCursor />
            <Header />
            <main className="relative min-h-screen">{children}</main>
            <Footer />
          </CartProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
