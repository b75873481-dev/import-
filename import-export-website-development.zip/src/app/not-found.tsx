import Link from "next/link";
import { MaskLines } from "@/components/motion/primitives";

export default function NotFound() {
  return (
    <div className="relative flex min-h-[80vh] items-center justify-center overflow-hidden bg-ink pt-32 pb-20">
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-45" />
      <div className="pointer-events-none absolute left-1/2 top-1/3 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-lime/[0.1] blur-[130px]" />
      <div className="relative mx-auto max-w-2xl px-6 text-center">
        <p className="font-mono-gt text-[10px] uppercase tracking-[0.34em] text-lime">Error 404</p>
        <h1 className="font-display mt-5 text-[clamp(3rem,12vw,7rem)] font-bold leading-none tracking-[-0.05em] text-bone">
          <MaskLines lines={[<span key="a">Off the</span>, <span key="b" className="text-lime">trade route.</span>]} />
        </h1>
        <p className="mx-auto mt-6 max-w-md text-sm leading-relaxed text-mist">
          The page or shipment reference you are looking for could not be located in our network.
        </p>
        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <Link
            href="/"
            className="rounded-full bg-lime px-7 py-3.5 text-sm font-bold text-ink transition hover:bg-bone"
          >
            Back to homepage
          </Link>
          <Link
            href="/tracking"
            className="rounded-full border border-white/15 px-7 py-3.5 text-sm font-semibold text-bone transition hover:border-lime hover:text-lime"
          >
            Track a shipment
          </Link>
        </div>
      </div>
    </div>
  );
}
