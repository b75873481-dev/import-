"use client";

import { motion, useReducedMotion } from "framer-motion";

const EASE = [0.16, 1, 0.3, 1] as const;

export function ConfirmationClient({
  orderNumber,
  customerName,
  email,
  paymentMethod,
  createdAt,
}: {
  orderNumber: string;
  customerName: string;
  email: string;
  paymentMethod: string;
  createdAt: string;
}) {
  const reduce = useReducedMotion();

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: EASE }}
      className="relative overflow-hidden rounded-[30px] border border-lime/25 bg-lime/[0.06] p-10 text-center"
    >
      <div className="pointer-events-none absolute inset-0 dot-bg opacity-25" />
      {!reduce && (
        <>
          <motion.span
            aria-hidden
            className="pointer-events-none absolute left-1/2 top-24 h-64 w-64 -translate-x-1/2 rounded-full bg-lime/20 blur-3xl"
            animate={{ scale: [0.7, 1.25, 0.9], opacity: [0.35, 0.7, 0.4] }}
            transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }}
          />
          {Array.from({ length: 12 }).map((_, i) => (
            <motion.span
              key={i}
              aria-hidden
              className="pointer-events-none absolute left-1/2 top-24 h-1.5 w-1.5 rounded-full bg-lime"
              initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
              animate={{
                x: Math.cos((i / 12) * Math.PI * 2) * 150,
                y: Math.sin((i / 12) * Math.PI * 2) * 150,
                opacity: 0,
                scale: 0.2,
              }}
              transition={{ duration: 1.4, delay: 0.35, ease: "easeOut" }}
            />
          ))}
        </>
      )}

      <div className="relative mx-auto flex h-20 w-20 items-center justify-center">
        {!reduce && <span className="absolute inset-0 rounded-full border border-lime/50 gt-pulse" />}
        <svg viewBox="0 0 52 52" className="h-20 w-20">
          <motion.circle
            cx="26"
            cy="26"
            r="23"
            fill="none"
            stroke="#c8ff3e"
            strokeWidth="2"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.9, ease: EASE }}
          />
          <motion.path
            d="M15 27.5 L22.5 35 L38 19"
            fill="none"
            stroke="#c8ff3e"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.55, delay: 0.75, ease: EASE }}
          />
        </svg>
      </div>

      <motion.h1
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5, ease: EASE }}
        className="font-display relative mt-6 text-[clamp(1.8rem,4.6vw,2.8rem)] font-bold leading-tight tracking-[-0.03em] text-bone"
      >
        Order confirmed
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.62, ease: EASE }}
        className="relative mx-auto mt-3 max-w-lg text-sm leading-relaxed text-mist"
      >
        Thank you, <span className="text-bone">{customerName}</span>. Your reference{" "}
        <span className="font-mono-gt text-lime">{orderNumber}</span> has been received and payment via{" "}
        <span className="text-bone">{paymentMethod}</span> was processed securely.
      </motion.p>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.76 }}
        className="font-mono-gt relative mt-4 text-[10px] uppercase tracking-[0.2em] text-mist"
      >
        Confirmation sent to {email} · {createdAt}
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.88 }}
        className="font-mono-gt relative mx-auto mt-7 flex max-w-md flex-wrap justify-center gap-2"
      >
        {["🔒 SSL secured", "🧾 Invoice generated", "🔗 ERP sync queued"].map((chip) => (
          <span key={chip} className="rounded-full border border-white/12 bg-ink/60 px-3 py-1.5 text-[9px] uppercase tracking-[0.16em] text-mist">
            {chip}
          </span>
        ))}
      </motion.div>
    </motion.div>
  );
}
