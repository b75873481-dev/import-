import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { ConfirmationClient } from "./ConfirmationClient";

export const dynamic = "force-dynamic";

interface OrderConfirmationProps {
  params: Promise<{ orderNumber: string }>;
}

export default async function OrderConfirmationPage({ params }: OrderConfirmationProps) {
  const { orderNumber } = await params;
  const [order] = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);

  if (!order) {
    notFound();
  }

  const items = order.items as { name: string; quantity: number; price: number; currency: string }[];

  return (
    <div className="min-h-screen bg-ink pt-32 pb-20">
      <div className="mx-auto max-w-3xl px-6">
        <ConfirmationClient
          orderNumber={order.orderNumber}
          customerName={order.customerName}
          email={order.email}
          paymentMethod={order.paymentMethod}
          createdAt={formatDateTime(order.createdAt)}
        />

        <div className="mt-6 rounded-[26px] border border-white/[0.08] bg-ink-2 p-7">
          <h2 className="font-display text-lg font-bold tracking-tight text-bone">Order items</h2>
          <div className="mt-5 space-y-3">
            {items.map((item, idx) => (
              <div key={idx} className="flex justify-between gap-3 text-sm">
                <span className="text-mist">
                  {item.name} <span className="font-mono-gt text-[10px] text-lime">×{item.quantity}</span>
                </span>
                <span className="shrink-0 font-semibold text-bone">
                  {formatCurrency(item.price * item.quantity, item.currency)}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-5 space-y-2.5 border-t border-white/[0.08] pt-5 text-sm">
            <div className="flex justify-between">
              <span className="text-mist">Subtotal</span>
              <span className="text-bone">{formatCurrency(order.subtotal, order.currency)}</span>
            </div>
            <div className="flex items-baseline justify-between border-t border-white/[0.08] pt-4">
              <span className="font-mono-gt text-[10px] uppercase tracking-[0.22em] text-mist">Total paid</span>
              <span className="font-display text-2xl font-bold text-lime">
                {formatCurrency(order.total, order.currency)}
              </span>
            </div>
          </div>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <NextCard href="/tracking" icon="🛰️" title="Track your shipment" body="A tracking number is issued once your order ships." />
          <NextCard href="/products" icon="📦" title="Continue browsing" body="Explore more certified import/export products." />
        </div>
      </div>
    </div>
  );
}

function NextCard({ href, icon, title, body }: { href: string; icon: string; title: string; body: string }) {
  return (
    <Link
      href={href}
      className="group rounded-[24px] border border-white/[0.08] bg-ink-2 p-6 transition-colors duration-500 hover:border-lime/35"
    >
      <span className="text-2xl transition-transform duration-500 group-hover:scale-110 inline-block">{icon}</span>
      <p className="font-display mt-3 text-sm font-bold text-bone transition-colors group-hover:text-lime">{title}</p>
      <p className="mt-1.5 text-xs leading-relaxed text-mist">{body}</p>
    </Link>
  );
}
