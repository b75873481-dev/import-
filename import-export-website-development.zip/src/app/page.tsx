import { db } from "@/db";
import { products, shipments } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import {
  Hero,
  Ticker,
  StatsBand,
  IntroSection,
  ServicesSection,
  FeaturedProducts,
  FeaturesSection,
  WhyUsSection,
  TestimonialsSection,
  PartnersSection,
  FaqSection,
  CtaSection,
} from "@/components/home/HomeClient";
import { LiveBoard } from "@/components/home/LiveBoard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const featured = await db
    .select({
      slug: products.slug,
      name: products.name,
      category: products.category,
      shortDescription: products.shortDescription,
      price: products.price,
      currency: products.currency,
      unit: products.unit,
      imageUrl: products.imageUrl,
      originCountry: products.originCountry,
      certifications: products.certifications,
    })
    .from(products)
    .where(eq(products.featured, true))
    .orderBy(desc(products.createdAt))
    .limit(4);

  const boardRows = (await db.select().from(shipments).orderBy(desc(shipments.createdAt))).map((s) => ({
    trackingNumber: s.trackingNumber,
    mode: s.mode,
    originPort: s.originPort,
    destinationPort: s.destinationPort,
    status: s.status,
    customsStatus: s.customsStatus,
    eta: s.eta.toISOString(),
  }));

  return (
    <>
      <Hero />
      <Ticker />
      <StatsBand />
      <IntroSection />
      <ServicesSection />
      <FeaturedProducts products={featured} />
      <section className="relative bg-ink py-24">
        <div className="mx-auto max-w-[1400px] px-6">
          <LiveBoard rows={boardRows} />
        </div>
      </section>
      <FeaturesSection />
      <WhyUsSection />
      <TestimonialsSection />
      <PartnersSection />
      <FaqSection />
      <CtaSection />
    </>
  );
}
