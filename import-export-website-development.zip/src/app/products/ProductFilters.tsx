"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";

export function ProductFilters({
  categories,
  activeCategory,
  query,
}: {
  categories: string[];
  activeCategory?: string;
  query?: string;
}) {
  const router = useRouter();
  const [search, setSearch] = useState(query ?? "");

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (activeCategory) params.set("category", activeCategory);
    if (search) params.set("q", search);
    router.push(`/products?${params.toString()}`);
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 22 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="flex flex-col gap-5 rounded-[26px] border border-white/[0.08] bg-ink-2 p-5 lg:flex-row lg:items-center lg:justify-between"
    >
      <div className="flex flex-wrap gap-2">
        <Link
          href="/products"
          className={`font-mono-gt rounded-full px-4 py-2 text-[10px] uppercase tracking-[0.16em] transition ${
            !activeCategory
              ? "bg-lime text-ink"
              : "border border-white/10 text-mist hover:border-lime/40 hover:text-lime"
          }`}
        >
          All
        </Link>
        {categories.map((c) => {
          const params = new URLSearchParams();
          params.set("category", c);
          if (query) params.set("q", query);
          const active = activeCategory === c;
          return (
            <Link
              key={c}
              href={`/products?${params.toString()}`}
              className={`relative rounded-full px-4 py-2 text-[11px] font-medium transition ${
                active ? "text-ink" : "border border-white/10 text-mist hover:border-lime/40 hover:text-lime"
              }`}
            >
              {active && (
                <motion.span
                  layoutId="filter-pill"
                  className="absolute inset-0 rounded-full bg-lime"
                  transition={{ type: "spring", stiffness: 400, damping: 32 }}
                />
              )}
              <span className="relative">{c}</span>
            </Link>
          );
        })}
      </div>

      <form onSubmit={handleSearch} className="flex w-full max-w-sm gap-2">
        <div className="relative flex-1">
          <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-mist">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="7" />
              <path d="m20 20-3.5-3.5" />
            </svg>
          </span>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search products, HS codes…"
            className="w-full rounded-full border border-white/10 bg-ink/60 py-2.5 pl-10 pr-4 text-sm text-bone placeholder:text-mist/60 transition focus:border-lime/50 focus:outline-none"
          />
        </div>
        <button
          type="submit"
          className="shrink-0 rounded-full bg-bone px-5 py-2.5 text-sm font-bold text-ink transition hover:bg-lime"
        >
          Search
        </button>
      </form>
    </motion.div>
  );
}
