"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Tilt } from "@/components/motion/primitives";

export interface GridProduct {
  slug: string;
  name: string;
  category: string;
  shortDescription: string;
  price: string;
  unit: string;
  imageUrl: string;
  originCountry: string;
  certifications: string[];
  stockStatus: string;
  leadTime: string;
}

const EASE = [0.16, 1, 0.3, 1] as const;

export function ProductGrid({ products }: { products: GridProduct[] }) {
  return (
    <motion.div
      layout
      className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
    >
      {products.map((p, i) => (
        <motion.div
          layout
          key={p.slug}
          initial={{ opacity: 0, y: 38 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65, delay: Math.min(i * 0.05, 0.4), ease: EASE }}
        >
          <Tilt className="h-full" max={6}>
            <Link
              href={`/products/${p.slug}`}
              className="flex h-full flex-col overflow-hidden rounded-[26px] border border-white/[0.08] bg-ink-2 transition-colors duration-500 hover:border-lime/35"
            >
              <div className="relative h-48 overflow-hidden bg-ink-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={p.imageUrl}
                  alt={p.name}
                  className="h-full w-full object-cover opacity-85 transition-all duration-700 group-hover/tilt:scale-110 group-hover/tilt:opacity-100"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-2 via-transparent to-transparent" />
                <span className="font-mono-gt absolute left-3 top-3 rounded-full border border-white/15 bg-ink/80 px-2.5 py-1 text-[9px] uppercase tracking-[0.14em] text-mist backdrop-blur">
                  {p.category}
                </span>
                <span
                  className={`font-mono-gt absolute right-3 top-3 rounded-full border px-2.5 py-1 text-[9px] uppercase tracking-[0.14em] backdrop-blur ${
                    p.stockStatus === "In Stock"
                      ? "border-lime/30 bg-lime/10 text-lime"
                      : "border-amber/30 bg-amber/10 text-amber"
                  }`}
                >
                  {p.stockStatus}
                </span>
              </div>

              <div className="flex flex-1 flex-col p-5">
                <h3 className="font-display text-[15px] font-bold leading-snug text-bone">{p.name}</h3>
                <p className="mt-2 line-clamp-3 flex-1 text-xs leading-relaxed text-mist">{p.shortDescription}</p>

                <div className="mt-4 flex flex-wrap gap-1.5">
                  {p.certifications.slice(0, 3).map((c) => (
                    <span
                      key={c}
                      className="font-mono-gt rounded-full border border-lime/20 bg-lime/[0.06] px-2 py-0.5 text-[9px] uppercase tracking-[0.1em] text-lime"
                    >
                      {c}
                    </span>
                  ))}
                </div>

                <div className="font-mono-gt mt-4 flex items-center justify-between text-[9px] uppercase tracking-[0.16em] text-mist">
                  <span>MOQ lead · {p.leadTime}</span>
                  <span>{p.originCountry}</span>
                </div>

                <div className="mt-4 flex items-end justify-between border-t border-white/[0.07] pt-4">
                  <div>
                    <p className="font-display text-lg font-bold text-lime">{p.price}</p>
                    <p className="font-mono-gt text-[9px] uppercase tracking-[0.16em] text-mist">per {p.unit}</p>
                  </div>
                  <span className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 text-bone transition-all duration-500 group-hover/tilt:border-lime group-hover/tilt:bg-lime group-hover/tilt:text-ink">
                    →
                  </span>
                </div>
              </div>
            </Link>
          </Tilt>
        </motion.div>
      ))}
    </motion.div>
  );
}
