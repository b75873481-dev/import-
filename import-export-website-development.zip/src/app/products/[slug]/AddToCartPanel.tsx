"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { useCart } from "@/lib/cart-context";
import { formatCurrency } from "@/lib/format";
import { Magnetic } from "@/components/motion/primitives";

const EASE = [0.16, 1, 0.3, 1] as const;

export function AddToCartPanel({
  slug,
  name,
  imageUrl,
  price,
  currency,
  unit,
}: {
  slug: string;
  name: string;
  imageUrl: string;
  price: number;
  currency: string;
  unit: string;
}) {
  const { addItem } = useCart();
  const router = useRouter();
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  function handleAdd() {
    addItem({ slug, name, imageUrl, price, currency, unit, quantity });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  }

  function handleBuyNow() {
    addItem({ slug, name, imageUrl, price, currency, unit, quantity });
    router.push("/cart");
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay: 0.2, ease: EASE }}
      className="relative overflow-hidden rounded-[28px] border border-white/[0.08] bg-ink-2 p-7"
    >
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-lime/60 to-transparent" />
      <div className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-lime/[0.08] blur-3xl" />

      <div className="relative">
        <p className="font-mono-gt text-[10px] uppercase tracking-[0.28em] text-mist">Unit price</p>
        <p className="font-display mt-2 text-4xl font-bold tracking-tight text-lime">
          {formatCurrency(price, currency)}
          <span className="ml-2 text-sm font-medium text-mist">/ {unit}</span>
        </p>

        <div className="mt-7">
          <p className="font-mono-gt text-[10px] uppercase tracking-[0.24em] text-mist">Quantity</p>
          <div className="mt-3 flex items-center gap-3">
            <button
              onClick={() => setQuantity((q) => Math.max(1, q - 1))}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-white/12 text-lg text-bone transition hover:border-lime hover:text-lime"
              aria-label="Decrease quantity"
            >
              −
            </button>
            <input
              type="number"
              min={1}
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, Number(e.target.value) || 1))}
              className="font-mono-gt h-11 w-20 rounded-full border border-white/12 bg-ink/60 text-center text-sm tabular-nums text-bone focus:border-lime/50 focus:outline-none"
              aria-label="Quantity"
            />
            <button
              onClick={() => setQuantity((q) => q + 1)}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-white/12 text-lg text-bone transition hover:border-lime hover:text-lime"
              aria-label="Increase quantity"
            >
              +
            </button>
            <motion.p
              key={quantity}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              className="font-display ml-auto text-right text-base font-bold text-bone"
            >
              {formatCurrency(price * quantity, currency)}
            </motion.p>
          </div>
        </div>

        <div className="mt-7 space-y-3">
          <Magnetic strength={0.22}>
            <button
              onClick={handleBuyNow}
              className="group relative w-full overflow-hidden rounded-full bg-lime px-6 py-3.5 text-sm font-bold text-ink"
            >
              <span className="relative z-10">Buy Now / Request Order</span>
              <span className="absolute inset-0 -translate-x-full bg-bone transition-transform duration-500 group-hover:translate-x-0" />
            </button>
          </Magnetic>
          <button
            onClick={handleAdd}
            className="relative w-full overflow-hidden rounded-full border border-white/15 px-6 py-3.5 text-sm font-semibold text-bone transition-colors hover:border-lime hover:text-lime"
          >
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={added ? "added" : "add"}
                initial={{ y: 14, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: -14, opacity: 0 }}
                transition={{ duration: 0.25, ease: EASE }}
                className="block"
              >
                {added ? "✓ Added to cart" : "Add to Cart"}
              </motion.span>
            </AnimatePresence>
          </button>
        </div>

        <div className="font-mono-gt mt-7 space-y-2.5 border-t border-white/[0.08] pt-5 text-[10px] uppercase tracking-[0.16em] text-mist">
          <p className="flex items-center gap-2">🔒 256-bit SSL encrypted checkout</p>
          <p className="flex items-center gap-2">💳 Card · Wire · Escrow · L/C accepted</p>
          <p className="flex items-center gap-2">🛰️ Live tracking number issued on confirm</p>
        </div>
      </div>
    </motion.div>
  );
}
