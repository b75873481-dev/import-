"use client";

import { motion } from "framer-motion";

export function CertBadges({ certifications }: { certifications: string[] }) {
  return (
    <div className="mt-5 flex flex-wrap gap-2.5">
      {certifications.map((c, i) => (
        <motion.span
          key={c}
          initial={{ opacity: 0, scale: 0.85 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ delay: i * 0.06, duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          whileHover={{ y: -3 }}
          className="font-mono-gt flex items-center gap-2 rounded-full border border-lime/25 bg-lime/[0.07] px-4 py-2 text-[10px] uppercase tracking-[0.16em] text-lime"
        >
          ✓ {c}
        </motion.span>
      ))}
    </div>
  );
}
