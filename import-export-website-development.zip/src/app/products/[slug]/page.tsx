import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { products } from "@/db/schema";
import { and, eq, ne } from "drizzle-orm";
import { formatCurrency } from "@/lib/format";
import { AddToCartPanel } from "./AddToCartPanel";
import { CertBadges } from "./CertBadges";
import { Parallax, Reveal, SectionLabel } from "@/components/motion/primitives";

export const dynamic = "force-dynamic";

interface ProductPageProps {
  params: Promise<{ slug: string }>;
}

export default async function ProductPage({ params }: ProductPageProps) {
  const { slug } = await params;
  const [product] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);

  if (!product) {
    notFound();
  }

  const related = await db
    .select()
    .from(products)
    .where(and(eq(products.category, product.category), ne(products.slug, product.slug)))
    .limit(3);

  const specs = [
    ["Origin Country", product.originCountry],
    ["Minimum Order", product.minOrderQuantity],
    ["Lead Time", product.leadTime],
    ["Stock Status", product.stockStatus],
    ["Unit", product.unit],
    ["Category", product.category],
  ];

  return (
    <div className="bg-ink">
      {/* hero */}
      <section className="relative overflow-hidden border-b border-white/[0.07] bg-ink-2 pt-32 pb-14">
        <div className="pointer-events-none absolute inset-0 grid-bg opacity-40" />
        <div className="pointer-events-none absolute -left-24 top-10 h-[380px] w-[380px] rounded-full bg-lime/[0.09] blur-[120px]" />
        <div className="relative mx-auto max-w-[1400px] px-6">
          <nav className="font-mono-gt flex flex-wrap items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-mist">
            <Link href="/products" className="transition-colors hover:text-lime">Products</Link>
            <span className="text-white/20">/</span>
            <span>{product.category}</span>
            <span className="text-white/20">/</span>
            <span className="text-lime">{product.name}</span>
          </nav>
          <h1 className="font-display mt-6 max-w-4xl text-[clamp(2rem,5vw,3.8rem)] font-bold leading-[1.02] tracking-[-0.035em] text-bone">
            {product.name}
          </h1>
          <p className="mt-5 max-w-2xl text-[15px] leading-relaxed text-mist">{product.shortDescription}</p>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-6 py-14">
        <div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <Reveal y={44}>
              <Parallax distance={30} className="rounded-[30px]">
                <div className="relative overflow-hidden rounded-[30px] border border-white/[0.08]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="h-[460px] w-full scale-110 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent" />
                  <span className="font-mono-gt absolute bottom-4 left-4 rounded-full border border-white/15 bg-ink/80 px-3 py-1.5 text-[9px] uppercase tracking-[0.2em] text-lime backdrop-blur">
                    {product.stockStatus}
                  </span>
                </div>
              </Parallax>
            </Reveal>

            <Reveal delay={0.1}>
              <div className="mt-10">
                <SectionLabel index="01">Specification</SectionLabel>
                <p className="mt-5 text-[15px] leading-relaxed text-mist">{product.description}</p>
              </div>
            </Reveal>

            <Reveal delay={0.14}>
              <div className="mt-9 grid grid-cols-2 gap-px overflow-hidden rounded-[26px] border border-white/[0.08] bg-white/[0.08] sm:grid-cols-3">
                {specs.map(([label, value]) => (
                  <div key={label} className="group bg-ink-2 px-5 py-5 transition-colors hover:bg-ink-3">
                    <p className="font-mono-gt text-[9px] uppercase tracking-[0.22em] text-mist">{label}</p>
                    <p className="mt-1.5 text-sm font-semibold text-bone transition-colors group-hover:text-lime">
                      {value}
                    </p>
                  </div>
                ))}
              </div>
            </Reveal>

            <Reveal delay={0.18}>
              <div className="mt-10">
                <SectionLabel index="02">Certifications &amp; Compliance</SectionLabel>
                <CertBadges certifications={product.certifications} />
                <p className="mt-5 max-w-2xl text-xs leading-relaxed text-mist">
                  All documentation — certificates of origin, lab test reports, safety data sheets and compliance
                  declarations — ships with every consignment, aligned to WTO, FDA and CE requirements where
                  applicable.
                </p>
              </div>
            </Reveal>
          </div>

          <div className="lg:sticky lg:top-28 lg:self-start">
            <AddToCartPanel
              slug={product.slug}
              name={product.name}
              imageUrl={product.imageUrl}
              price={Number(product.price)}
              currency={product.currency}
              unit={product.unit}
            />
          </div>
        </div>

        {related.length > 0 && (
          <div className="mt-20">
            <SectionLabel index="03">Related</SectionLabel>
            <h2 className="font-display mt-5 text-2xl font-bold tracking-tight text-bone">More in {product.category}</h2>
            <div className="mt-7 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((r, i) => (
                <Reveal key={r.slug} delay={i * 0.08}>
                  <Link
                    href={`/products/${r.slug}`}
                    className="group flex gap-4 overflow-hidden rounded-[24px] border border-white/[0.08] bg-ink-2 p-3 transition-colors duration-500 hover:border-lime/35"
                  >
                    <div className="h-24 w-24 shrink-0 overflow-hidden rounded-2xl bg-ink-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={r.imageUrl}
                        alt={r.name}
                        className="h-full w-full object-cover opacity-85 transition-transform duration-700 group-hover:scale-110"
                      />
                    </div>
                    <div className="flex flex-1 flex-col justify-center">
                      <h3 className="font-display text-sm font-bold leading-snug text-bone">{r.name}</h3>
                      <p className="font-display mt-2 text-base font-bold text-lime">
                        {formatCurrency(r.price, r.currency)}
                        <span className="font-mono-gt ml-1.5 text-[9px] uppercase tracking-[0.16em] text-mist">
                          / {r.unit}
                        </span>
                      </p>
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
