import Link from "next/link";
import { db } from "@/db";
import { products } from "@/db/schema";
import { and, asc, eq, ilike, or } from "drizzle-orm";
import { formatCurrency } from "@/lib/format";
import { ProductFilters } from "./ProductFilters";
import { ProductGrid } from "./ProductGrid";

export const dynamic = "force-dynamic";

const categories = [
  "Food & Beverage",
  "Industrial & Raw Materials",
  "Medical & Healthcare",
  "Energy & Electronics",
  "Textiles & Apparel",
];

interface ProductsPageProps {
  searchParams: Promise<{ category?: string; q?: string }>;
}

export default async function ProductsPage({ searchParams }: ProductsPageProps) {
  const { category, q } = await searchParams;

  const conditions = [];
  if (category) conditions.push(eq(products.category, category));
  if (q) {
    conditions.push(or(ilike(products.name, `%${q}%`), ilike(products.shortDescription, `%${q}%`)));
  }

  const list = await db
    .select()
    .from(products)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(asc(products.name));

  return (
    <div className="bg-ink">
      <section className="relative overflow-hidden border-b border-white/[0.07] bg-ink-2 pt-36 pb-16">
        <div className="pointer-events-none absolute inset-0 grid-bg opacity-40" />
        <div className="pointer-events-none absolute -left-32 top-0 h-[420px] w-[420px] rounded-full bg-lime/[0.1] blur-[120px]" />
        <div className="relative mx-auto max-w-[1400px] px-6">
          <p className="font-mono-gt text-[10px] uppercase tracking-[0.34em] text-lime">
            <span className="mr-2 inline-block h-1.5 w-1.5 translate-y-[-1px] rounded-full bg-lime gt-blink" />
            Product Catalog · {list.length} SKUs
          </p>
          <h1 className="font-display mt-5 max-w-3xl text-[clamp(2.2rem,5.6vw,4.2rem)] font-bold leading-[1.0] tracking-[-0.035em] text-bone">
            Certified products, sourced globally,{" "}
            <span className="text-lime">verified for compliance.</span>
          </h1>
          <p className="mt-5 max-w-2xl text-[15px] leading-relaxed text-mist">
            Every listing includes detailed specifications, certifications (WTO / FDA / CE / ISO), transparent
            pricing and minimum order quantities — so you can plan your import or export with confidence.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-6 py-12">
        <ProductFilters categories={categories} activeCategory={category} query={q} />

        {list.length === 0 ? (
          <div className="mt-16 rounded-[28px] border border-dashed border-white/15 bg-ink-2 p-16 text-center">
            <p className="font-display text-lg font-bold text-bone">No products match your search.</p>
            <Link href="/products" className="mt-4 inline-block text-sm font-semibold text-lime hover:underline">
              Clear filters
            </Link>
          </div>
        ) : (
          <ProductGrid
            products={list.map((p) => ({
              slug: p.slug,
              name: p.name,
              category: p.category,
              shortDescription: p.shortDescription,
              price: formatCurrency(p.price, p.currency),
              unit: p.unit,
              imageUrl: p.imageUrl,
              originCountry: p.originCountry,
              certifications: p.certifications,
              stockStatus: p.stockStatus,
              leadTime: p.leadTime,
            }))}
          />
        )}
      </section>
    </div>
  );
}
