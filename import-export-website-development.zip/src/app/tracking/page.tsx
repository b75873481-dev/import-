"use client";

import { useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { formatDate, formatDateTime } from "@/lib/format";
import { Magnetic, Reveal } from "@/components/motion/primitives";

interface Shipment {
  id: number;
  trackingNumber: string;
  status: string;
  mode: string;
  originPort: string;
  destinationPort: string;
  customerName: string;
  productSummary: string;
  customsStatus: string;
  eta: string;
}

interface ShipmentEvent {
  id: number;
  status: string;
  location: string;
  note: string | null;
  occurredAt: string;
}

const SAMPLES = ["UC-2026-100245", "UC-2026-100312", "UC-2026-100378", "UC-2026-100421", "UC-2026-100456"];

const STAGES = [
  "Order Confirmed",
  "Export Customs Cleared",
  "Loaded on Vessel",
  "Departed Origin",
  "In Transit - Ocean Freight",
  "In Transit - Road Freight",
  "Arrived Destination Hub",
  "Arrived Destination Port",
  "Customs Clearance - Destination",
  "Delivered",
];

const MODE_ICON: Record<string, string> = { Sea: "🚢", Air: "✈️", Land: "🚛" };

const EASE = [0.16, 1, 0.3, 1] as const;

function tone(status: string) {
  const s = status.toLowerCase();
  if (s.includes("deliver")) return { text: "text-lime", border: "border-lime/35", bg: "bg-lime/10", dot: "#c8ff3e" };
  if (s.includes("customs")) return { text: "text-amber", border: "border-amber/35", bg: "bg-amber/10", dot: "#ffb545" };
  return { text: "text-signal", border: "border-signal/35", bg: "bg-signal/10", dot: "#4ea8ff" };
}

export default function TrackingPage() {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ shipment: Shipment; events: ShipmentEvent[] } | null>(null);
  const reduce = useReducedMotion();

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch(`/api/shipments/${encodeURIComponent(query.trim())}`);
      if (!res.ok) throw new Error("not found");
      setResult(await res.json());
    } catch {
      setError("We could not find a shipment with that tracking number. Please check and try again.");
    } finally {
      setLoading(false);
    }
  }

  const progressIndex = result ? Math.max(0, STAGES.findIndex((s) => s === result.shipment.status)) : -1;
  const progressPct = result ? ((progressIndex + 1) / STAGES.length) * 100 : 0;
  const t = result ? tone(result.shipment.status) : tone("");

  return (
    <div className="bg-ink">
      {/* search hero */}
      <section className="relative overflow-hidden border-b border-white/[0.07] bg-ink-2 pt-36 pb-20">
        <div className="pointer-events-none absolute inset-0 grid-bg opacity-45" />
        <motion.div
          animate={reduce ? undefined : { scale: [1, 1.15, 1], opacity: [0.3, 0.55, 0.3] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          className="pointer-events-none absolute left-1/2 top-0 h-[420px] w-[620px] -translate-x-1/2 rounded-full bg-lime/[0.1] blur-[130px]"
        />
        <div className="relative mx-auto max-w-3xl px-6 text-center">
          <Reveal>
            <p className="font-mono-gt text-[10px] uppercase tracking-[0.34em] text-lime">
              <span className="mr-2 inline-block h-1.5 w-1.5 translate-y-[-1px] rounded-full bg-lime gt-blink" />
              Real-time visibility
            </p>
          </Reveal>
          <h1 className="font-display mt-5 text-[clamp(2.2rem,6vw,4.2rem)] font-bold leading-[1.0] tracking-[-0.04em] text-bone">
            <Reveal y={26}>Track your shipment</Reveal>
            <Reveal y={26} delay={0.08}>
              <span className="text-lime">&amp; customs clearance.</span>
            </Reveal>
          </h1>
          <Reveal delay={0.16}>
            <p className="mx-auto mt-5 max-w-xl text-[15px] leading-relaxed text-mist">
              Enter your GlobexTrade reference to view live milestones across export filing, transit and destination
              customs clearance.
            </p>
          </Reveal>

          <Reveal delay={0.24}>
            <form onSubmit={handleSearch} className="mx-auto mt-9 flex max-w-xl gap-2.5">
              <div className="relative flex-1">
                <span className="font-mono-gt pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[10px] uppercase tracking-[0.2em] text-mist">
                  REF
                </span>
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="UC-2026-100312"
                  className="font-mono-gt w-full rounded-full border border-white/12 bg-ink/70 py-4 pl-14 pr-5 text-sm text-bone placeholder:text-mist/50 transition focus:border-lime/60 focus:outline-none"
                />
              </div>
              <Magnetic strength={0.25}>
                <button
                  type="submit"
                  disabled={loading}
                  className="group relative h-full shrink-0 overflow-hidden rounded-full bg-lime px-7 text-sm font-bold text-ink disabled:opacity-60"
                >
                  <span className="relative z-10">{loading ? "Scanning…" : "Track"}</span>
                  <span className="absolute inset-0 -translate-x-full bg-bone transition-transform duration-500 group-hover:translate-x-0" />
                </button>
              </Magnetic>
            </form>
          </Reveal>

          <Reveal delay={0.32}>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
              <span className="font-mono-gt text-[10px] uppercase tracking-[0.24em] text-mist">Try:</span>
              {SAMPLES.map((s) => (
                <button
                  key={s}
                  onClick={() => setQuery(s)}
                  className="font-mono-gt rounded-full border border-white/10 px-3 py-1.5 text-[10px] tracking-tight text-mist transition hover:border-lime/50 hover:text-lime"
                >
                  {s}
                </button>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-6 py-14">
        <AnimatePresence mode="wait">
          {error && (
            <motion.div
              key="err"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              className="rounded-[26px] border border-red-500/25 bg-red-500/[0.07] p-7 text-center text-sm text-red-300"
            >
              {error}
            </motion.div>
          )}

          {!result && !error && (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="rounded-[26px] border border-dashed border-white/12 bg-ink-2 p-20 text-center"
            >
              <motion.div
                animate={reduce ? undefined : { y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-white/10 bg-ink text-2xl"
              >
                🛰️
              </motion.div>
              <p className="font-display mt-5 text-lg font-bold text-bone">Awaiting reference</p>
              <p className="mx-auto mt-2 max-w-sm text-sm text-mist">
                Enter a tracking number above to view live shipment and customs clearance status.
              </p>
            </motion.div>
          )}

          {result && (
            <motion.div key={result.shipment.trackingNumber} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-8">
              {/* header card */}
              <motion.div
                initial={{ opacity: 0, y: 26 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, ease: EASE }}
                className="relative overflow-hidden rounded-[28px] border border-white/[0.08] bg-ink-2 p-7"
              >
                <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-lime/60 to-transparent" />
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <p className="font-mono-gt text-[10px] uppercase tracking-[0.28em] text-mist">Tracking number</p>
                    <p className="font-display mt-1.5 text-2xl font-bold tracking-tight text-bone">
                      {result.shipment.trackingNumber}
                    </p>
                  </div>
                  <span className={`font-mono-gt flex items-center gap-2 rounded-full border px-4 py-2 text-[10px] uppercase tracking-[0.18em] ${t.border} ${t.bg} ${t.text}`}>
                    <span className="inline-block h-1.5 w-1.5 rounded-full bg-current gt-blink" />
                    {result.shipment.status}
                  </span>
                </div>

                {/* route visualiser */}
                <div className="mt-9">
                  <div className="flex items-center justify-between gap-4">
                    <Endpoint label="Origin" value={result.shipment.originPort} />
                    <div className="hidden shrink-0 items-center gap-2 sm:flex">
                      <span className="font-mono-gt rounded-full border border-white/10 px-3 py-1 text-[10px] uppercase tracking-[0.16em] text-mist">
                        {MODE_ICON[result.shipment.mode]} {result.shipment.mode}
                      </span>
                    </div>
                    <Endpoint label="Destination" value={result.shipment.destinationPort} align="right" />
                  </div>

                  <div className="relative mt-6 h-16">
                    <div className="absolute inset-x-0 top-1/2 h-px -translate-y-1/2 bg-white/10" />
                    <motion.div
                      className="absolute left-0 top-1/2 h-px -translate-y-1/2 bg-gradient-to-r from-lime to-signal"
                      initial={{ width: 0 }}
                      animate={{ width: `${progressPct}%` }}
                      transition={{ duration: 1.4, ease: EASE, delay: 0.25 }}
                    />
                    {STAGES.map((_, i) => {
                      const left = ((i + 1) / STAGES.length) * 100;
                      const reached = i <= progressIndex;
                      return (
                        <motion.span
                          key={i}
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: 0.3 + i * 0.06, type: "spring", stiffness: 400, damping: 20 }}
                          className={`absolute top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full ${
                            reached ? "bg-lime" : "bg-white/15"
                          }`}
                          style={{ left: `${left}%` }}
                        />
                      );
                    })}
                    <motion.div
                      initial={{ left: "0%" }}
                      animate={{ left: `${progressPct}%` }}
                      transition={{ duration: 1.4, ease: EASE, delay: 0.25 }}
                      className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2"
                    >
                      <span className="relative flex h-8 w-8 items-center justify-center">
                        {!reduce && (
                          <span className="absolute inset-0 rounded-full border border-lime gt-pulse" />
                        )}
                        <span className="relative flex h-8 w-8 items-center justify-center rounded-full border border-lime/50 bg-ink text-sm">
                          {MODE_ICON[result.shipment.mode] ?? "📦"}
                        </span>
                      </span>
                    </motion.div>
                  </div>

                  <div className="font-mono-gt flex items-center justify-between text-[9px] uppercase tracking-[0.22em] text-mist">
                    <span>Stage {progressIndex + 1}/{STAGES.length}</span>
                    <span className="text-lime">{progressPct.toFixed(0)}% complete</span>
                  </div>
                </div>

                <div className="mt-8 grid grid-cols-2 gap-px overflow-hidden rounded-[22px] border border-white/[0.08] bg-white/[0.08] sm:grid-cols-4">
                  <Cell label="Customer" value={result.shipment.customerName} />
                  <Cell label="Customs" value={result.shipment.customsStatus} accent />
                  <Cell label="ETA" value={formatDate(result.shipment.eta)} />
                  <Cell label="Mode" value={result.shipment.mode} />
                </div>

                <p className="mt-5 rounded-[20px] border border-white/[0.07] bg-ink/60 p-4 text-sm text-mist">
                  <span className="font-mono-gt mr-2 text-[10px] uppercase tracking-[0.2em] text-lime">Cargo</span>
                  {result.shipment.productSummary}
                </p>
              </motion.div>

              {/* timeline */}
              <motion.div
                initial={{ opacity: 0, y: 26 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.15, ease: EASE }}
                className="rounded-[28px] border border-white/[0.08] bg-ink-2 p-7"
              >
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-lg font-bold tracking-tight text-bone">Shipment Timeline</h2>
                  <span className="font-mono-gt flex items-center gap-2 text-[10px] uppercase tracking-[0.22em] text-mist">
                    <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime gt-blink" /> Live
                  </span>
                </div>

                <ol className="relative mt-8 space-y-7 pl-8">
                  <motion.span
                    className="absolute left-[7px] top-2 w-px bg-gradient-to-b from-lime via-signal to-transparent"
                    initial={{ height: 0 }}
                    animate={{ height: "100%" }}
                    transition={{ duration: 1.2, ease: EASE, delay: 0.3 }}
                  />
                  {result.events.map((event, idx) => {
                    const last = idx === result.events.length - 1;
                    return (
                      <motion.li
                        key={event.id}
                        initial={{ opacity: 0, x: -22 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.55, delay: 0.35 + idx * 0.1, ease: EASE }}
                        className="relative"
                      >
                        <span
                          className={`absolute -left-8 top-1 flex h-[15px] w-[15px] items-center justify-center rounded-full border-2 ${
                            last ? "border-lime bg-lime" : "border-white/25 bg-ink"
                          }`}
                        >
                          {last && !reduce && (
                            <span className="absolute inset-0 rounded-full border border-lime gt-pulse" />
                          )}
                        </span>
                        <p className={`font-display text-sm font-bold ${last ? "text-lime" : "text-bone"}`}>
                          {event.status}
                        </p>
                        <p className="font-mono-gt mt-1 text-[10px] uppercase tracking-[0.16em] text-mist">
                          {event.location} · {formatDateTime(event.occurredAt)}
                        </p>
                        {event.note && <p className="mt-1.5 max-w-xl text-sm leading-relaxed text-mist">{event.note}</p>}
                      </motion.li>
                    );
                  })}
                </ol>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </section>
    </div>
  );
}

function Endpoint({ label, value, align = "left" }: { label: string; value: string; align?: "left" | "right" }) {
  return (
    <div className={`min-w-0 flex-1 ${align === "right" ? "text-right" : ""}`}>
      <p className="font-mono-gt text-[9px] uppercase tracking-[0.26em] text-mist">{label}</p>
      <p className="font-display mt-1 truncate text-sm font-bold text-bone">{value}</p>
    </div>
  );
}

function Cell({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="group bg-ink-2 px-4 py-4 transition-colors hover:bg-ink-3">
      <p className="font-mono-gt text-[9px] uppercase tracking-[0.22em] text-mist">{label}</p>
      <p className={`mt-1 text-sm font-semibold ${accent ? "text-amber" : "text-bone"}`}>{value}</p>
    </div>
  );
}
