"use client";

import Link from "next/link";
import { useState } from "react";
import { motion } from "framer-motion";
import { useLanguage } from "@/i18n/LanguageProvider";
import { Magnetic, Marquee, Reveal } from "@/components/motion/primitives";

const columns = [
  {
    title: "Trade",
    links: [
      { href: "/products", label: "Product Catalog" },
      { href: "/tracking", label: "Shipment Tracking" },
      { href: "/cart", label: "Cart & Checkout" },
      { href: "/dashboard", label: "Operations Dashboard" },
    ],
  },
  {
    title: "Compliance",
    links: [
      { href: "/compliance", label: "WTO Alignment" },
      { href: "/compliance", label: "FDA Registration" },
      { href: "/compliance", label: "CE Marking" },
      { href: "/compliance", label: "ISO Standards" },
    ],
  },
  {
    title: "Company",
    links: [
      { href: "/about", label: "About Us" },
      { href: "/about", label: "Our Standards" },
      { href: "/contact", label: "Contact" },
      { href: "/contact", label: "Request a Quote" },
    ],
  },
];

export function Footer() {
  const { t } = useLanguage();
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");

  async function handleSubscribe(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error();
      setStatus("done");
      setEmail("");
    } catch {
      setStatus("error");
    }
  }

  return (
    <footer className="relative overflow-hidden border-t border-white/[0.07] bg-ink-2">
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-30" />
      <div className="pointer-events-none absolute -left-40 top-0 h-[420px] w-[420px] rounded-full bg-lime/[0.07] blur-[120px]" />

      {/* kinetic wordmark */}
      <div className="relative border-b border-white/[0.06] py-10">
        <Marquee speed={34}>
          <span className="font-display flex items-center gap-8 px-4 text-[clamp(2.6rem,9vw,7.5rem)] font-bold leading-none tracking-tighter">
            <span className="text-stroke">IMPORT</span>
            <span className="text-lime">•</span>
            <span className="text-bone">EXPORT</span>
            <span className="text-lime">•</span>
            <span className="text-stroke">COMPLIANCE</span>
            <span className="text-lime">•</span>
            <span className="text-bone">LOGISTICS</span>
            <span className="text-lime">•</span>
          </span>
        </Marquee>
      </div>

      <div className="relative mx-auto max-w-[1400px] px-6 py-16">
        <div className="grid gap-12 lg:grid-cols-[1.5fr_1fr_1fr_1fr_1.4fr]">
          <Reveal>
            <Link href="/" className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-lime font-display text-sm font-bold text-ink">
                GT
              </span>
              <span className="font-display text-lg font-bold tracking-tight text-bone">
                GLOBEX<span className="text-lime">TRADE</span>
              </span>
            </Link>
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-mist">{t("footer_tagline")}</p>
            <div className="mt-6 flex flex-wrap gap-2">
              {["ISO 9001", "WTO", "FDA", "CE", "PCI-DSS"].map((badge) => (
                <span
                  key={badge}
                  className="font-mono-gt rounded-full border border-white/10 px-3 py-1 text-[10px] uppercase tracking-[0.14em] text-mist"
                >
                  {badge}
                </span>
              ))}
            </div>
          </Reveal>

          {columns.map((col, i) => (
            <Reveal key={col.title} delay={0.08 * (i + 1)}>
              <h4 className="font-mono-gt text-[10px] uppercase tracking-[0.3em] text-lime">{col.title}</h4>
              <ul className="mt-5 space-y-3">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <Link
                      href={l.href}
                      className="group inline-flex items-center gap-1.5 text-sm text-mist transition-colors hover:text-bone"
                    >
                      <span className="h-px w-0 bg-lime transition-all duration-300 group-hover:w-3" />
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </Reveal>
          ))}

          <Reveal delay={0.3}>
            <h4 className="font-mono-gt text-[10px] uppercase tracking-[0.3em] text-lime">Trade Intel</h4>
            <p className="mt-5 text-sm text-mist">
              Regulation updates, new catalog drops and shipping advisories — no noise.
            </p>
            <form onSubmit={handleSubscribe} className="mt-5">
              <div className="flex items-center gap-2 rounded-full border border-white/10 bg-ink/60 p-1.5 transition focus-within:border-lime/50">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@company.com"
                  className="w-full bg-transparent px-3.5 py-2 text-sm text-bone placeholder:text-mist/60 focus:outline-none"
                />
                <Magnetic strength={0.2}>
                  <button
                    type="submit"
                    disabled={status === "loading"}
                    className="shrink-0 rounded-full bg-lime px-4 py-2 text-xs font-bold text-ink transition hover:bg-bone disabled:opacity-60"
                  >
                    {status === "loading" ? "..." : "Join"}
                  </button>
                </Magnetic>
              </div>
            </form>
            {status === "done" && (
              <motion.p
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-3 text-xs text-lime"
              >
                ✓ Subscribed. Welcome aboard.
              </motion.p>
            )}
            {status === "error" && (
              <p className="mt-3 text-xs text-amber">Something went wrong — try again.</p>
            )}
          </Reveal>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-5 border-t border-white/[0.07] pt-8 sm:flex-row">
          <p className="font-mono-gt text-[11px] uppercase tracking-[0.16em] text-mist">
            © {new Date().getFullYear()} GlobexTrade Co. — {t("footer_rights")}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
            <span className="font-mono-gt flex items-center gap-2 text-[11px] uppercase tracking-[0.16em] text-mist">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime gt-blink" />
              256-bit SSL Secured
            </span>
            <span className="font-mono-gt text-[11px] uppercase tracking-[0.16em] text-mist">Privacy</span>
            <span className="font-mono-gt text-[11px] uppercase tracking-[0.16em] text-mist">Terms of Trade</span>
            <span className="font-mono-gt text-[11px] uppercase tracking-[0.16em] text-mist">
              v4.2.1 · Patched {new Date().toLocaleDateString("en-US", { month: "short", year: "numeric" })}
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
