"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion, useScroll, useMotionValueEvent } from "framer-motion";
import { useLanguage } from "@/i18n/LanguageProvider";
import { locales } from "@/i18n/translations";
import { useCart } from "@/lib/cart-context";
import { Magnetic } from "@/components/motion/primitives";

const navItems = [
  { href: "/products", key: "nav_products" as const },
  { href: "/tracking", key: "nav_tracking" as const },
  { href: "/compliance", key: "nav_compliance" as const },
  { href: "/dashboard", key: "nav_dashboard" as const },
  { href: "/about", key: "nav_about" as const },
  { href: "/contact", key: "nav_contact" as const },
];

export function Header() {
  const { t, locale, setLocale } = useLanguage();
  const { count } = useCart();
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    const prev = scrollY.getPrevious() ?? 0;
    setScrolled(latest > 40);
    if (latest > 320 && latest > prev + 6) setHidden(true);
    else if (latest < prev - 6 || latest < 200) setHidden(false);
  });

  useEffect(() => {
    setOpen(false);
    setLangOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <motion.header
        initial={{ y: -90, opacity: 0 }}
        animate={{ y: hidden ? -110 : 0, opacity: 1 }}
        transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
        className="fixed inset-x-0 top-0 z-[80]"
      >
        {/* top utility strip */}
        <div
          className={`hidden overflow-hidden border-b border-white/5 bg-ink-2/80 text-[11px] backdrop-blur transition-all duration-500 md:block ${
            scrolled ? "max-h-0 opacity-0" : "max-h-10 opacity-100"
          }`}
        >
          <div className="mx-auto flex max-w-[1400px] items-center justify-between px-6 py-2.5">
            <p className="font-mono-gt uppercase tracking-[0.2em] text-mist">
              <span className="mr-2 inline-block h-1.5 w-1.5 translate-y-[-1px] rounded-full bg-lime gt-blink" />
              {t("topbar_message")}
            </p>
            <div className="flex items-center gap-6">
              <span className="font-mono-gt uppercase tracking-[0.2em] text-mist">
                {t("topbar_support")}
              </span>
              <a href="tel:+18005550192" className="font-mono-gt tracking-[0.1em] text-lime hover:underline">
                +1 (800) 555-0192
              </a>
            </div>
          </div>
        </div>

        <div
          className={`border-b transition-all duration-500 ${
            scrolled
              ? "border-white/[0.07] bg-ink/85 backdrop-blur-xl"
              : "border-transparent bg-gradient-to-b from-ink/70 to-transparent"
          }`}
        >
          <div className="mx-auto flex max-w-[1400px] items-center justify-between gap-4 px-6 py-4">
            <Link href="/" className="group flex items-center gap-3">
              <motion.span
                whileHover={{ rotate: -12, scale: 1.08 }}
                transition={{ type: "spring", stiffness: 320, damping: 14 }}
                className="relative flex h-10 w-10 items-center justify-center"
              >
                <span className="absolute inset-0 rounded-xl bg-lime" />
                <span className="absolute inset-0 rounded-xl bg-lime opacity-60 blur-md" />
                <span className="font-display relative text-sm font-bold text-ink">GT</span>
              </motion.span>
              <span className="font-display text-lg font-bold leading-none tracking-tight text-bone">
                GLOBEX<span className="text-lime">TRADE</span>
              </span>
            </Link>

            <nav className="hidden items-center gap-1 lg:flex">
              {navItems.map((item) => {
                const active = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="group relative px-3.5 py-2 text-[13px] font-medium text-mist transition-colors hover:text-bone"
                  >
                    <span className={active ? "text-bone" : ""}>{t(item.key)}</span>
                    {active && (
                      <motion.span
                        layoutId="nav-active"
                        className="absolute inset-x-3 -bottom-px h-px bg-lime"
                        transition={{ type: "spring", stiffness: 380, damping: 30 }}
                      />
                    )}
                    <span className="absolute inset-x-3 bottom-0 h-px origin-left scale-x-0 bg-lime/60 transition-transform duration-300 group-hover:scale-x-100" />
                  </Link>
                );
              })}
            </nav>

            <div className="flex items-center gap-2">
              <div className="relative hidden sm:block">
                <button
                  onClick={() => setLangOpen((v) => !v)}
                  className="font-mono-gt flex items-center gap-2 rounded-full border border-white/10 px-3.5 py-2 text-[11px] uppercase tracking-[0.18em] text-mist transition hover:border-lime/50 hover:text-lime"
                >
                  <span>{locales.find((l) => l.code === locale)?.flag}</span>
                  {locale}
                  <svg width="8" height="8" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.6">
                    <path d="M1 3.5 5 7.5 9 3.5" />
                  </svg>
                </button>
                <AnimatePresence>
                  {langOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -8, scale: 0.96 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -8, scale: 0.96 }}
                      transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
                      className="absolute right-0 top-[calc(100%+10px)] w-44 overflow-hidden rounded-2xl border border-white/10 bg-ink-2/95 p-1.5 shadow-2xl backdrop-blur-xl"
                    >
                      {locales.map((l) => (
                        <button
                          key={l.code}
                          onClick={() => {
                            setLocale(l.code);
                            setLangOpen(false);
                          }}
                          className={`flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-[13px] transition ${
                            l.code === locale ? "bg-lime/10 text-lime" : "text-mist hover:bg-white/5 hover:text-bone"
                          }`}
                        >
                          <span>{l.flag}</span>
                          {l.label}
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <Link
                href="/cart"
                aria-label={t("nav_cart")}
                className="relative flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-mist transition hover:border-lime/50 hover:text-lime"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <circle cx="9" cy="20" r="1.4" />
                  <circle cx="19" cy="20" r="1.4" />
                  <path d="M1.5 2h3.6l2.4 12.2a1.8 1.8 0 0 0 1.8 1.4h8.9a1.8 1.8 0 0 0 1.8-1.4L22 6H5.4" />
                </svg>
                <AnimatePresence>
                  {count > 0 && (
                    <motion.span
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      exit={{ scale: 0 }}
                      transition={{ type: "spring", stiffness: 500, damping: 22 }}
                      className="font-mono-gt absolute -right-1 -top-1 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-lime px-1 text-[10px] font-bold text-ink"
                    >
                      {count}
                    </motion.span>
                  )}
                </AnimatePresence>
              </Link>

              <Magnetic strength={0.28} className="hidden md:block">
                <Link
                  href="/contact"
                  className="group relative inline-flex items-center gap-2 overflow-hidden rounded-full bg-lime px-5 py-2.5 text-[13px] font-semibold text-ink"
                >
                  <span className="relative z-10">{t("nav_get_quote")}</span>
                  <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-0.5">→</span>
                  <span className="absolute inset-0 -translate-x-full bg-bone transition-transform duration-500 group-hover:translate-x-0" />
                </Link>
              </Magnetic>

              <button
                onClick={() => setOpen(true)}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-mist lg:hidden"
                aria-label="Open menu"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M3 7h18M3 17h18" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Mobile drawer */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[95] bg-ink/95 backdrop-blur-xl lg:hidden"
          >
            <div className="absolute inset-0 dot-bg opacity-30" />
            <div className="relative flex h-full flex-col">
              <div className="flex items-center justify-between px-6 py-5">
                <span className="font-display text-lg font-bold">
                  GLOBEX<span className="text-lime">TRADE</span>
                </span>
                <button
                  onClick={() => setOpen(false)}
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10"
                  aria-label="Close menu"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                    <path d="M18 6 6 18M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <nav className="flex flex-1 flex-col justify-center gap-1 px-6">
                {navItems.map((item, i) => (
                  <motion.div
                    key={item.href}
                    initial={{ opacity: 0, x: -30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.08 + i * 0.06, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                    className="overflow-hidden border-b border-white/[0.06]"
                  >
                    <Link
                      href={item.href}
                      onClick={() => setOpen(false)}
                      className="font-display block py-4 text-3xl font-bold tracking-tight text-bone transition-colors hover:text-lime"
                    >
                      {t(item.key)}
                    </Link>
                  </motion.div>
                ))}
              </nav>
              <div className="px-6 pb-10">
                <p className="font-mono-gt mb-3 text-[10px] uppercase tracking-[0.3em] text-mist">Language</p>
                <div className="flex flex-wrap gap-2">
                  {locales.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => setLocale(l.code)}
                      className={`rounded-full border px-4 py-2 text-xs transition ${
                        l.code === locale
                          ? "border-lime bg-lime/10 text-lime"
                          : "border-white/10 text-mist"
                      }`}
                    >
                      {l.flag} {l.label}
                    </button>
                  ))}
                </div>
                <Link
                  href="/contact"
                  onClick={() => setOpen(false)}
                  className="mt-6 block rounded-full bg-lime px-6 py-3.5 text-center text-sm font-semibold text-ink"
                >
                  {t("nav_get_quote")}
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
