"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import {
  AnimatePresence,
  motion,
  useMotionValue,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
} from "framer-motion";
import { useLanguage } from "@/i18n/LanguageProvider";
import { formatCurrency } from "@/lib/format";
import {
  Counter,
  Magnetic,
  Marquee,
  MaskLines,
  Parallax,
  Reveal,
  ScrambleText,
  SectionLabel,
  Tilt,
} from "@/components/motion/primitives";
import { TradeGlobe } from "./TradeGlobe";

export interface FeaturedProduct {
  slug: string;
  name: string;
  category: string;
  shortDescription: string;
  price: string;
  currency: string;
  unit: string;
  imageUrl: string;
  originCountry: string;
  certifications: string[];
}

const EASE = [0.16, 1, 0.3, 1] as const;

/* ══════════════════════════ HERO ══════════════════════════ */

export function Hero() {
  const { t } = useLanguage();
  const reduce = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], reduce ? [0, 0] : [0, 160]);
  const opacity = useTransform(scrollYProgress, [0, 0.75], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, reduce ? 1 : 0.94]);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const smx = useSpring(mx, { stiffness: 60, damping: 20 });
  const smy = useSpring(my, { stiffness: 60, damping: 20 });
  const orbX = useTransform(smx, (v) => v * 26);
  const orbY = useTransform(smy, (v) => v * 26);

  return (
    <section
      ref={ref}
      className="relative flex min-h-[100svh] items-center overflow-hidden bg-ink pt-28 pb-16"
      onMouseMove={(e) => {
        const cx = e.clientX / window.innerWidth - 0.5;
        const cy = e.clientY / window.innerHeight - 0.5;
        mx.set(cx);
        my.set(cy);
      }}
    >
      {/* atmosphere */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 grid-bg opacity-[0.55]" />
        <motion.div
          style={{ x: orbX, y: orbY }}
          className="gt-aurora absolute -left-[18%] top-[-12%] h-[640px] w-[640px] rounded-full bg-lime/[0.13] blur-[130px]"
        />
        <motion.div
          style={{ x: orbX, y: orbY }}
          className="gt-aurora absolute -right-[14%] top-[18%] h-[560px] w-[560px] rounded-full bg-signal/[0.14] blur-[130px]"
          // eslint-disable-next-line react/no-unknown-property
        />
        <motion.div
          style={{ x: orbX, y: orbY }}
          className="gt-aurora absolute bottom-[-20%] left-[30%] h-[520px] w-[520px] rounded-full bg-lime/[0.07] blur-[140px]"
        />
        <div className="absolute inset-x-0 bottom-0 h-56 bg-gradient-to-t from-ink to-transparent" />
      </div>

      <motion.div
        style={{ y, opacity, scale }}
        className="relative mx-auto grid w-full max-w-[1400px] gap-14 px-6 lg:grid-cols-[1.08fr_0.92fr] lg:items-center"
      >
        <div>
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15, ease: EASE }}
            className="flex flex-wrap items-center gap-3"
          >
            <span className="font-mono-gt flex items-center gap-2 rounded-full border border-lime/25 bg-lime/[0.07] px-3.5 py-1.5 text-[10px] uppercase tracking-[0.28em] text-lime">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime gt-blink" />
              {t("hero_eyebrow")}
            </span>
            <span className="font-mono-gt text-[10px] uppercase tracking-[0.24em] text-mist">
              EST. 2011 · 62 COUNTRIES
            </span>
          </motion.div>

          <h1 className="font-display mt-7 text-[clamp(2.7rem,7.6vw,6.4rem)] font-bold leading-[0.94] tracking-[-0.035em]">
            <MaskLines
              delay={0.22}
              lines={[
                <span key="1">{t("hero_title_1")}</span>,
                <span key="2" className="text-lime">
                  {t("hero_title_2")}
                </span>,
                <span key="3" className="text-stroke">
                  {t("hero_title_3")}
                </span>,
              ]}
            />
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.85, delay: 0.62, ease: EASE }}
            className="mt-7 max-w-xl text-[15px] leading-relaxed text-mist"
          >
            {t("hero_sub")}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.85, delay: 0.76, ease: EASE }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <Magnetic strength={0.32}>
              <Link
                href="/products"
                className="group relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-lime px-7 py-3.5 text-sm font-bold text-ink"
              >
                <span className="relative z-10">{t("hero_cta_primary")}</span>
                <span className="relative z-10 transition-transform duration-500 group-hover:translate-x-1">→</span>
                <span className="absolute inset-0 -translate-x-full bg-bone transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:translate-x-0" />
              </Link>
            </Magnetic>
            <Magnetic strength={0.25}>
              <Link
                href="/tracking"
                className="group inline-flex items-center gap-3 rounded-full border border-white/15 px-7 py-3.5 text-sm font-semibold text-bone transition-colors hover:border-lime hover:text-lime"
              >
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full rounded-full bg-lime opacity-60 gt-pulse" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-lime" />
                </span>
                {t("hero_cta_secondary")}
              </Link>
            </Magnetic>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1 }}
            className="font-mono-gt mt-11 flex flex-wrap gap-x-7 gap-y-3 text-[10px] uppercase tracking-[0.2em] text-mist"
          >
            {[
              ["🔒", "SSL ENCRYPTED"],
              ["✅", "WTO / FDA / CE"],
              ["🔗", "SAP · ORACLE"],
              ["💳", "PCI-DSS PAYMENTS"],
            ].map(([icon, label]) => (
              <span key={label} className="flex items-center gap-2">
                <span aria-hidden>{icon}</span>
                {label}
              </span>
            ))}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.4, ease: EASE }}
          className="relative"
        >
          <TradeGlobe />
        </motion.div>
      </motion.div>

      {/* scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4 }}
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 lg:flex"
      >
        <span className="font-mono-gt text-[9px] uppercase tracking-[0.3em] text-mist">Scroll</span>
        <span className="relative block h-12 w-px overflow-hidden bg-white/10">
          <motion.span
            className="absolute inset-x-0 top-0 h-4 bg-lime"
            animate={reduce ? undefined : { y: [-16, 48] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          />
        </span>
      </motion.div>
    </section>
  );
}

/* ══════════════════════════ TICKER ══════════════════════════ */

export function Ticker() {
  const items = [
    "HS CLASSIFICATION", "CERTIFICATE OF ORIGIN", "BONDED WAREHOUSING", "LETTER OF CREDIT",
    "PHYTOSANITARY CERTS", "INCOTERMS 2020", "DUTY DRAWBACK", "COLD CHAIN MONITORING",
    "BILL OF LADING", "CUSTOMS BROKERAGE", "TRADE FINANCE", "OOG & HEAVY LIFT",
  ];
  return (
    <div className="relative border-y border-white/[0.07] bg-ink-2 py-4">
      <Marquee speed={52}>
        <span className="font-mono-gt flex items-center gap-8 px-4 text-[11px] uppercase tracking-[0.32em] text-mist">
          {items.map((item) => (
            <span key={item} className="flex items-center gap-8">
              {item}
              <span className="text-lime">◆</span>
            </span>
          ))}
        </span>
      </Marquee>
    </div>
  );
}

/* ══════════════════════════ STATS ══════════════════════════ */

const STATS = [
  { key: "stat_shipments" as const, value: 3400, suffix: "+", decimals: 0 },
  { key: "stat_ontime" as const, value: 98.6, suffix: "%", decimals: 1 },
  { key: "stat_years" as const, value: 15, suffix: "+", decimals: 0 },
  { key: "stat_countries" as const, value: 62, suffix: "", decimals: 0 },
];

export function StatsBand() {
  const { t } = useLanguage();
  return (
    <section className="relative overflow-hidden bg-ink py-20">
      <div className="pointer-events-none absolute inset-0 dot-bg opacity-25" />
      <div className="relative mx-auto max-w-[1400px] px-6">
        <div className="grid gap-px overflow-hidden rounded-3xl border border-white/[0.08] bg-white/[0.08] sm:grid-cols-2 lg:grid-cols-4">
          {STATS.map((s, i) => (
            <motion.div
              key={s.key}
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: i * 0.09, ease: EASE }}
              className="group relative bg-ink px-7 py-9 transition-colors duration-500 hover:bg-ink-2"
            >
              <span className="absolute inset-x-0 top-0 h-px scale-x-0 bg-lime transition-transform duration-500 group-hover:scale-x-100" />
              <p className="font-display text-[clamp(2.2rem,5vw,3.4rem)] font-bold leading-none tracking-tight text-bone">
                <Counter to={s.value} decimals={s.decimals} suffix={s.suffix} />
              </p>
              <p className="font-mono-gt mt-3 text-[10px] uppercase tracking-[0.24em] text-mist">{t(s.key)}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ══════════════════════════ INTRO (sticky two-column) ══════════════════════════ */

export function IntroSection() {
  const { t } = useLanguage();
  return (
    <section className="relative bg-ink-2 py-24">
      <div className="mx-auto grid max-w-[1400px] gap-14 px-6 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
        <div className="lg:sticky lg:top-32">
          <SectionLabel index="01">Who we are</SectionLabel>
          <h2 className="font-display mt-6 text-[clamp(2rem,4.4vw,3.6rem)] font-bold leading-[1.02] tracking-[-0.03em]">
            <MaskLines lines={[<span key="a">{t("intro_title")}</span>]} />
          </h2>
          <Reveal delay={0.12}>
            <p className="mt-7 max-w-lg text-[15px] leading-relaxed text-mist">{t("intro_body_1")}</p>
            <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-mist">{t("intro_body_2")}</p>
          </Reveal>
          <Reveal delay={0.22}>
            <Magnetic strength={0.25} className="mt-8 inline-block">
              <Link
                href="/about"
                className="group inline-flex items-center gap-3 text-sm font-semibold text-lime"
              >
                {t("intro_cta")}
                <span className="flex h-8 w-8 items-center justify-center rounded-full border border-lime/40 transition-transform duration-500 group-hover:translate-x-1.5">
                  →
                </span>
              </Link>
            </Magnetic>
          </Reveal>
        </div>

        <Reveal y={50}>
          <Parallax distance={44} className="rounded-[32px]">
            <div className="relative overflow-hidden rounded-[32px] border border-white/[0.08]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="https://images.pexels.com/photos/262353/pexels-photo-262353.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
                alt="Cargo vessel loaded with containers at sea"
                className="h-[520px] w-full scale-110 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/25 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-7">
                <div className="flex flex-wrap gap-3">
                  {[
                    ["2,500+", "Active SKUs"],
                    ["3,400+", "Shipments / mo"],
                    ["24/7", "Trade desk"],
                  ].map(([v, l]) => (
                    <div key={l} className="glass rounded-2xl px-4 py-3">
                      <p className="font-display text-lg font-bold text-lime">{v}</p>
                      <p className="font-mono-gt text-[9px] uppercase tracking-[0.2em] text-mist">{l}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Parallax>
        </Reveal>
      </div>
    </section>
  );
}

/* ══════════════════════════ SERVICES (hover-reveal list) ══════════════════════════ */

const SERVICES = [
  {
    title: "service_catalog_title" as const,
    body: "service_catalog_body" as const,
    href: "/products",
    img: "https://images.pexels.com/photos/9716365/pexels-photo-9716365.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    tag: "CATALOG",
  },
  {
    title: "service_payments_title" as const,
    body: "service_payments_body" as const,
    href: "/cart",
    img: "https://images.pexels.com/photos/40118381/pexels-photo-40118381.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    tag: "PAYMENTS",
  },
  {
    title: "service_tracking_title" as const,
    body: "service_tracking_body" as const,
    href: "/tracking",
    img: "https://images.pexels.com/photos/2231744/pexels-photo-2231744.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    tag: "TRACKING",
  },
  {
    title: "service_compliance_title" as const,
    body: "service_compliance_body" as const,
    href: "/compliance",
    img: "https://images.pexels.com/photos/6572432/pexels-photo-6572432.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    tag: "COMPLIANCE",
  },
  {
    title: "service_erp_title" as const,
    body: "service_erp_body" as const,
    href: "/dashboard",
    img: "https://images.pexels.com/photos/28752153/pexels-photo-28752153.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    tag: "ERP",
  },
  {
    title: "service_accounting_title" as const,
    body: "service_accounting_body" as const,
    href: "/dashboard",
    img: "https://images.pexels.com/photos/33622086/pexels-photo-33622086.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    tag: "FINANCE",
  },
];

export function ServicesSection() {
  const { t } = useLanguage();
  const [active, setActive] = useState<number | null>(null);
  const px = useMotionValue(0);
  const py = useMotionValue(0);
  const sx = useSpring(px, { stiffness: 180, damping: 24 });
  const sy = useSpring(py, { stiffness: 180, damping: 24 });

  return (
    <section
      className="relative bg-ink py-24"
      onMouseMove={(e) => {
        px.set(e.clientX);
        py.set(e.clientY);
      }}
    >
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-30" />
      <div className="relative mx-auto max-w-[1400px] px-6">
        <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
          <div className="lg:sticky lg:top-32">
            <SectionLabel index="02">Capabilities</SectionLabel>
            <h2 className="font-display mt-6 text-[clamp(2rem,4.4vw,3.6rem)] font-bold leading-[1.02] tracking-[-0.03em]">
              <MaskLines
                lines={[
                  <span key="1">{t("services_title").split(".")[0]}.</span>,
                  <span key="2" className="text-lime">
                    {t("services_title").split(".").slice(1).join(".").trim()}
                  </span>,
                ]}
              />
            </h2>
            <Reveal delay={0.14}>
              <p className="mt-6 max-w-md text-[15px] leading-relaxed text-mist">{t("services_sub")}</p>
            </Reveal>
            <Reveal delay={0.22}>
              <div className="font-mono-gt mt-8 flex items-center gap-3 text-[10px] uppercase tracking-[0.24em] text-mist">
                <span className="text-lime">{String((active ?? 0) + 1).padStart(2, "0")}</span>
                <span className="h-px w-16 bg-line" />
                <span>{String(SERVICES.length).padStart(2, "0")}</span>
              </div>
            </Reveal>
          </div>

          <div className="relative">
            {SERVICES.map((s, i) => (
              <motion.div
                key={s.tag}
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.65, delay: i * 0.06, ease: EASE }}
                onMouseEnter={() => setActive(i)}
                onMouseLeave={() => setActive(null)}
                className="border-b border-white/[0.07] first:border-t"
              >
                <Link href={s.href} className="group flex items-center gap-5 py-7">
                  <span className="font-mono-gt w-8 shrink-0 text-[10px] tabular-nums text-mist transition-colors group-hover:text-lime">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="flex-1">
                    <span className="font-display block text-[clamp(1.35rem,2.9vw,2.1rem)] font-bold leading-tight tracking-[-0.02em] text-bone transition-all duration-500 group-hover:translate-x-2 group-hover:text-lime">
                      {t(s.title)}
                    </span>
                    <span className="mt-1.5 block max-w-md text-sm text-mist opacity-0 transition-all duration-500 group-hover:translate-x-2 group-hover:opacity-100">
                      {t(s.body)}
                    </span>
                  </span>
                  <span className="font-mono-gt hidden shrink-0 rounded-full border border-white/10 px-3 py-1 text-[9px] uppercase tracking-[0.2em] text-mist sm:block">
                    {s.tag}
                  </span>
                  <span className="shrink-0 text-lg text-mist transition-all duration-500 group-hover:translate-x-1 group-hover:text-lime">
                    →
                  </span>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* cursor-following preview */}
      <AnimatePresence>
        {active !== null && (
          <motion.div
            style={{ x: sx, y: sy }}
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.85 }}
            transition={{ duration: 0.35, ease: EASE }}
            className="pointer-events-none fixed left-0 top-0 z-40 hidden -translate-x-1/2 -translate-y-1/2 lg:block"
          >
            <div className="relative h-56 w-80 overflow-hidden rounded-2xl border border-white/10 shadow-2xl">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={SERVICES[active].img}
                alt=""
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/85 to-transparent" />
              <span className="font-mono-gt absolute bottom-3 left-3 text-[9px] uppercase tracking-[0.24em] text-lime">
                {SERVICES[active].tag}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

/* ══════════════════════════ FEATURED PRODUCTS ══════════════════════════ */

export function FeaturedProducts({ products }: { products: FeaturedProduct[] }) {
  const { t } = useLanguage();
  return (
    <section className="relative overflow-hidden bg-ink-2 py-24">
      <div className="pointer-events-none absolute -right-40 top-20 h-[460px] w-[460px] rounded-full bg-signal/[0.08] blur-[130px]" />
      <div className="relative mx-auto max-w-[1400px] px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <SectionLabel index="03">Catalog</SectionLabel>
            <h2 className="font-display mt-6 max-w-xl text-[clamp(2rem,4.4vw,3.4rem)] font-bold leading-[1.03] tracking-[-0.03em]">
              <MaskLines
                lines={[
                  <span key="a">Certified goods,</span>,
                  <span key="b" className="text-lime">
                    ready to cross borders.
                  </span>,
                ]}
              />
            </h2>
          </div>
          <Reveal delay={0.15}>
            <Magnetic strength={0.25}>
              <Link
                href="/products"
                className="group inline-flex items-center gap-3 rounded-full border border-white/15 px-6 py-3 text-sm font-semibold text-bone transition-colors hover:border-lime hover:text-lime"
              >
                {t("hero_cta_primary")}
                <span className="transition-transform duration-500 group-hover:translate-x-1">→</span>
              </Link>
            </Magnetic>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((p, i) => (
            <motion.div
              key={p.slug}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.7, delay: i * 0.08, ease: EASE }}
            >
              <Tilt className="h-full" max={7}>
                <Link
                  href={`/products/${p.slug}`}
                  className="flex h-full flex-col overflow-hidden rounded-[26px] border border-white/[0.08] bg-ink/70 transition-colors duration-500 hover:border-lime/35"
                >
                  <div className="relative h-48 overflow-hidden bg-ink-3">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={p.imageUrl}
                      alt={p.name}
                      className="h-full w-full object-cover opacity-85 transition-all duration-700 group-hover/tilt:scale-110 group-hover/tilt:opacity-100"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent" />
                    <span className="font-mono-gt absolute left-3 top-3 rounded-full border border-white/15 bg-ink/80 px-2.5 py-1 text-[9px] uppercase tracking-[0.16em] text-mist backdrop-blur">
                      {p.category}
                    </span>
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    <h3 className="font-display text-[15px] font-bold leading-snug text-bone">{p.name}</h3>
                    <p className="mt-2 line-clamp-2 flex-1 text-xs leading-relaxed text-mist">{p.shortDescription}</p>
                    <div className="mt-4 flex flex-wrap gap-1.5">
                      {p.certifications.slice(0, 3).map((c) => (
                        <span
                          key={c}
                          className="font-mono-gt rounded-full border border-lime/20 bg-lime/[0.06] px-2 py-0.5 text-[9px] uppercase tracking-[0.1em] text-lime"
                        >
                          {c}
                        </span>
                      ))}
                    </div>
                    <div className="mt-5 flex items-end justify-between border-t border-white/[0.07] pt-4">
                      <div>
                        <p className="font-display text-lg font-bold text-lime">
                          {formatCurrency(p.price, p.currency)}
                        </p>
                        <p className="font-mono-gt text-[9px] uppercase tracking-[0.16em] text-mist">{p.unit}</p>
                      </div>
                      <span className="font-mono-gt text-[9px] uppercase tracking-[0.16em] text-mist">
                        {p.originCountry}
                      </span>
                    </div>
                  </div>
                </Link>
              </Tilt>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ══════════════════════════ FEATURES ══════════════════════════ */

const FEATURES = [
  { title: "feature_1_title" as const, body: "feature_1_body" as const, icon: "📍", metric: "LIVE" },
  { title: "feature_2_title" as const, body: "feature_2_body" as const, icon: "🔐", metric: "256-BIT" },
  { title: "feature_3_title" as const, body: "feature_3_body" as const, icon: "☎️", metric: "24/7" },
];

export function FeaturesSection() {
  const { t } = useLanguage();
  return (
    <section className="relative bg-ink py-24">
      <div className="mx-auto max-w-[1400px] px-6">
        <div className="max-w-2xl">
          <SectionLabel index="04">Reliability</SectionLabel>
          <h2 className="font-display mt-6 text-[clamp(2rem,4.4vw,3.4rem)] font-bold leading-[1.03] tracking-[-0.03em]">
            <MaskLines lines={[<span key="a">{t("features_title")}</span>]} />
          </h2>
          <Reveal delay={0.12}>
            <p className="mt-5 text-[15px] leading-relaxed text-mist">{t("features_sub")}</p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 36 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: i * 0.11, ease: EASE }}
              whileHover={{ y: -8 }}
              className="group relative overflow-hidden rounded-[26px] border border-white/[0.08] bg-ink-2 p-8"
            >
              <div className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-lime/0 blur-3xl transition-all duration-700 group-hover:bg-lime/[0.14]" />
              <div className="relative flex items-start justify-between">
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl border border-white/[0.08] bg-ink text-2xl transition-transform duration-500 group-hover:scale-110 group-hover:border-lime/40">
                  {f.icon}
                </span>
                <span className="font-mono-gt rounded-full border border-lime/25 px-2.5 py-1 text-[9px] uppercase tracking-[0.2em] text-lime">
                  {f.metric}
                </span>
              </div>
              <h3 className="font-display relative mt-6 text-xl font-bold tracking-tight text-bone">{t(f.title)}</h3>
              <p className="relative mt-3 text-sm leading-relaxed text-mist">{t(f.body)}</p>
              <span className="absolute inset-x-0 bottom-0 h-px scale-x-0 bg-lime transition-transform duration-700 group-hover:scale-x-100" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ══════════════════════════ WHY US ══════════════════════════ */

const WHY = [
  { title: "why_1_title" as const, body: "why_1_body" as const },
  { title: "why_2_title" as const, body: "why_2_body" as const },
  { title: "why_3_title" as const, body: "why_3_body" as const },
  { title: "why_4_title" as const, body: "why_4_body" as const },
  { title: "why_5_title" as const, body: "why_5_body" as const },
];

export function WhyUsSection() {
  const { t } = useLanguage();
  return (
    <section className="relative bg-ink-2 py-24">
      <div className="mx-auto max-w-[1400px] px-6">
        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
          <div className="lg:sticky lg:top-32 lg:self-start">
            <SectionLabel index="05">Why GlobexTrade</SectionLabel>
            <h2 className="font-display mt-6 text-[clamp(1.9rem,4vw,3.1rem)] font-bold leading-[1.04] tracking-[-0.03em]">
              <MaskLines lines={[<span key="a">{t("why_title")}</span>]} />
            </h2>
            <Reveal delay={0.14}>
              <div className="mt-8 overflow-hidden rounded-3xl border border-white/[0.08]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="https://images.pexels.com/photos/31570314/pexels-photo-31570314.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
                  alt="Cargo loading at night"
                  className="h-56 w-full object-cover opacity-80"
                />
              </div>
            </Reveal>
          </div>

          <div className="space-y-3">
            {WHY.map((w, i) => (
              <motion.div
                key={w.title}
                initial={{ opacity: 0, x: 34 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.65, delay: i * 0.07, ease: EASE }}
                className="group relative flex gap-6 overflow-hidden rounded-[26px] border border-white/[0.08] bg-ink p-7 transition-colors duration-500 hover:border-lime/30"
              >
                <span className="font-display text-3xl font-bold leading-none text-white/[0.12] transition-colors duration-500 group-hover:text-lime/40">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <div>
                  <h3 className="font-display text-lg font-bold tracking-tight text-bone">{t(w.title)}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-mist">{t(w.body)}</p>
                </div>
                <span className="pointer-events-none absolute inset-y-0 -left-full w-full bg-gradient-to-r from-transparent via-lime/[0.05] to-transparent transition-all duration-1000 group-hover:left-full" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ══════════════════════════ TESTIMONIALS ══════════════════════════ */

const TESTIMONIALS = [
  {
    quote:
      "GlobexTrade's compliance team caught a labeling issue before our FDA filing — they saved us weeks of delay. Our account manager knows our business inside out.",
    name: "Sarah Mitchell",
    role: "VP Procurement · Atlantic Foods Group",
    country: "USA",
  },
  {
    quote:
      "We integrated our SAP inventory directly with their platform. Purchase orders, customs documents and shipment status all flow automatically now.",
    name: "Daniel Oyelaran",
    role: "Supply Chain Director · Lagos Industrial Partners",
    country: "NGA",
  },
  {
    quote:
      "First-time exporter here. Their team walked us through CE marking requirements step by step. Our first shipment cleared customs with zero issues.",
    name: "Mei Lin Chen",
    role: "Founder · Chen Textiles Co.",
    country: "SGP",
  },
];

export function TestimonialsSection() {
  const { t } = useLanguage();
  const [[index, dir], setState] = useState<[number, number]>([0, 0]);
  const item = TESTIMONIALS[index];

  function go(next: number) {
    const d = next > index ? 1 : -1;
    setState([((next % TESTIMONIALS.length) + TESTIMONIALS.length) % TESTIMONIALS.length, d]);
  }

  return (
    <section className="relative overflow-hidden bg-ink py-24">
      <div className="pointer-events-none absolute inset-0 dot-bg opacity-20" />
      <div className="relative mx-auto max-w-[1400px] px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <SectionLabel index="06">Clients</SectionLabel>
            <h2 className="font-display mt-6 max-w-2xl text-[clamp(1.9rem,4vw,3.1rem)] font-bold leading-[1.04] tracking-[-0.03em]">
              <MaskLines lines={[<span key="a">{t("testimonials_title")}</span>]} />
            </h2>
          </div>
          <div className="flex gap-3">
            <Magnetic strength={0.3}>
              <button
                onClick={() => go(index - 1)}
                className="flex h-12 w-12 items-center justify-center rounded-full border border-white/15 text-bone transition-colors hover:border-lime hover:text-lime"
                aria-label="Previous testimonial"
              >
                ←
              </button>
            </Magnetic>
            <Magnetic strength={0.3}>
              <button
                onClick={() => go(index + 1)}
                className="flex h-12 w-12 items-center justify-center rounded-full border border-white/15 text-bone transition-colors hover:border-lime hover:text-lime"
                aria-label="Next testimonial"
              >
                →
              </button>
            </Magnetic>
          </div>
        </div>

        <div className="mt-12 overflow-hidden rounded-[32px] border border-white/[0.08] bg-ink-2 p-10 md:p-14">
          <div className="relative min-h-[230px]">
            <AnimatePresence mode="wait" custom={dir}>
              <motion.blockquote
                key={index}
                custom={dir}
                initial={{ opacity: 0, x: dir * 70 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: dir * -70 }}
                transition={{ duration: 0.55, ease: EASE }}
              >
                <span className="font-display text-5xl leading-none text-lime">“</span>
                <p className="font-display mt-4 text-[clamp(1.15rem,2.5vw,1.9rem)] font-medium leading-[1.4] tracking-[-0.01em] text-bone">
                  {item.quote}
                </p>
                <footer className="mt-8 flex flex-wrap items-center gap-4">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full border border-lime/30 bg-lime/10 font-display text-sm font-bold text-lime">
                    {item.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </span>
                  <span>
                    <span className="block text-sm font-semibold text-bone">{item.name}</span>
                    <span className="font-mono-gt block text-[10px] uppercase tracking-[0.2em] text-mist">
                      {item.role}
                    </span>
                  </span>
                  <span className="font-mono-gt ml-auto rounded-full border border-white/10 px-3 py-1 text-[9px] uppercase tracking-[0.2em] text-mist">
                    {item.country}
                  </span>
                </footer>
              </motion.blockquote>
            </AnimatePresence>
          </div>

          <div className="mt-8 flex gap-2">
            {TESTIMONIALS.map((_, i) => (
              <button
                key={i}
                onClick={() => go(i)}
                aria-label={`Go to testimonial ${i + 1}`}
                className={`h-1 rounded-full transition-all duration-500 ${
                  i === index ? "w-12 bg-lime" : "w-6 bg-white/15 hover:bg-white/30"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ══════════════════════════ PARTNERS ══════════════════════════ */

const PARTNERS_A = [
  "SAP", "ORACLE NETSUITE", "MAERSK", "DHL GLOBAL FORWARDING", "COSCO SHIPPING",
  "KUEHNE+NAGEL", "DB SCHENKER", "FEDEX TRADE NETWORKS",
];
const PARTNERS_B = [
  "QUICKBOOKS", "XERO", "MICROSOFT DYNAMICS", "CMA CGM", "MSC", "HAPAG-LLOYD",
  "EVERGREEN LINE", "NYK LINE",
];

export function PartnersSection() {
  const { t } = useLanguage();
  return (
    <section className="relative border-y border-white/[0.07] bg-ink-2 py-16">
      <div className="mx-auto max-w-[1400px] px-6">
        <p className="font-mono-gt text-center text-[10px] uppercase tracking-[0.34em] text-mist">
          <ScrambleText text={t("partners_title")} />
        </p>
      </div>
      <div className="mt-9 space-y-4">
        <Marquee speed={44}>
          <span className="flex items-center gap-12 px-6">
            {PARTNERS_A.map((p) => (
              <span
                key={p}
                className="font-display text-xl font-bold uppercase tracking-tight text-white/25 transition-colors duration-300 hover:text-lime"
              >
                {p}
              </span>
            ))}
          </span>
        </Marquee>
        <Marquee speed={52} reverse>
          <span className="flex items-center gap-12 px-6">
            {PARTNERS_B.map((p) => (
              <span
                key={p}
                className="font-display text-xl font-bold uppercase tracking-tight text-white/20 transition-colors duration-300 hover:text-signal"
              >
                {p}
              </span>
            ))}
          </span>
        </Marquee>
      </div>
    </section>
  );
}

/* ══════════════════════════ FAQ ══════════════════════════ */

const FAQS = [
  { q: "What does GlobexTrade Co. do?", a: "We are a global import/export platform offering a certified product catalog, secure payments, real-time shipment tracking and full regulatory compliance support for cross-border trade." },
  { q: "Which regulations do you comply with?", a: "All catalog products and shipments are managed in alignment with WTO trade rules, FDA requirements for applicable goods and CE marking for the EU market, plus ISO quality standards." },
  { q: "What payment options are available?", a: "We support credit/debit cards, bank wire transfer, escrow-protected trade finance and letters of credit for large B2B orders — all processed through PCI-DSS compliant gateways." },
  { q: "Can I track my shipment in real time?", a: "Yes. Every order generates a tracking number with live milestone updates covering export clearance, transit, destination customs and final delivery." },
  { q: "Do you integrate with our ERP system?", a: "Yes — native connectors for SAP and Oracle NetSuite, plus a documented REST API for custom ERP, WMS and accounting integrations." },
  { q: "Is my data and payment information secure?", a: "All traffic is protected with 256-bit SSL encryption and payments run through PCI-DSS compliant gateways. We apply regular security patches and run routine penetration tests." },
  { q: "Do you support multiple languages?", a: "The platform is live in English, Spanish, French and Chinese, with more languages planned as we expand into new markets." },
  { q: "What is your minimum order quantity?", a: "MOQs vary by product and are listed on each product page — from bulk container loads to smaller trial orders for new partners." },
];

export function FaqSection() {
  const { t } = useLanguage();
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="relative bg-ink py-24">
      <div className="mx-auto max-w-[1000px] px-6">
        <div className="text-center">
          <div className="flex justify-center">
            <SectionLabel index="07">FAQ</SectionLabel>
          </div>
          <h2 className="font-display mt-6 text-[clamp(2rem,4.4vw,3.4rem)] font-bold leading-[1.03] tracking-[-0.03em]">
            <MaskLines lines={[<span key="a">{t("faq_sub")}</span>]} />
          </h2>
        </div>

        <div className="mt-12 border-t border-white/[0.08]">
          {FAQS.map((faq, i) => {
            const isOpen = open === i;
            return (
              <motion.div
                key={faq.q}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.5, delay: i * 0.04, ease: EASE }}
                className="border-b border-white/[0.08]"
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="group flex w-full items-center justify-between gap-6 py-6 text-left"
                >
                  <span className="flex items-baseline gap-4">
                    <span className="font-mono-gt text-[10px] tabular-nums text-mist">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span
                      className={`font-display text-base font-semibold transition-colors duration-300 md:text-lg ${
                        isOpen ? "text-lime" : "text-bone group-hover:text-lime"
                      }`}
                    >
                      {faq.q}
                    </span>
                  </span>
                  <motion.span
                    animate={{ rotate: isOpen ? 45 : 0 }}
                    transition={{ duration: 0.35, ease: EASE }}
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-white/15 text-sm text-bone transition-colors group-hover:border-lime group-hover:text-lime"
                  >
                    +
                  </motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.45, ease: EASE }}
                      className="overflow-hidden"
                    >
                      <p className="max-w-2xl pb-7 pl-9 text-sm leading-relaxed text-mist">{faq.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ══════════════════════════ CTA ══════════════════════════ */

export function CtaSection() {
  const { t } = useLanguage();
  const reduce = useReducedMotion();
  return (
    <section className="relative overflow-hidden bg-ink-2 py-28">
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-40" />
      <motion.div
        animate={reduce ? undefined : { scale: [1, 1.18, 1], opacity: [0.35, 0.6, 0.35] }}
        transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
        className="pointer-events-none absolute left-1/2 top-1/2 h-[560px] w-[560px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-lime/[0.12] blur-[120px]"
      />
      <div className="relative mx-auto max-w-4xl px-6 text-center">
        <SectionLabel index="08">Start now</SectionLabel>
        <h2 className="font-display mx-auto mt-6 max-w-3xl text-[clamp(2.3rem,6vw,4.6rem)] font-bold leading-[0.98] tracking-[-0.04em]">
          <MaskLines
            lines={[
              <span key="a">{t("cta_title")}</span>,
            ]}
          />
        </h2>
        <Reveal delay={0.14}>
          <p className="mx-auto mt-6 max-w-xl text-[15px] leading-relaxed text-mist">{t("cta_sub")}</p>
        </Reveal>
        <Reveal delay={0.24}>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <Magnetic strength={0.32}>
              <Link
                href="/contact"
                className="group relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-lime px-8 py-4 text-sm font-bold text-ink"
              >
                <span className="relative z-10">{t("cta_button")}</span>
                <span className="relative z-10 transition-transform duration-500 group-hover:translate-x-1">→</span>
                <span className="absolute inset-0 -translate-x-full bg-bone transition-transform duration-500 group-hover:translate-x-0" />
              </Link>
            </Magnetic>
            <Magnetic strength={0.25}>
              <Link
                href="/products"
                className="inline-flex items-center gap-3 rounded-full border border-white/15 px-8 py-4 text-sm font-semibold text-bone transition-colors hover:border-lime hover:text-lime"
              >
                {t("hero_cta_primary")}
              </Link>
            </Magnetic>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
