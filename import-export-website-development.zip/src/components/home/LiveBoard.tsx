"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";

export interface BoardRow {
  trackingNumber: string;
  mode: string;
  originPort: string;
  destinationPort: string;
  status: string;
  customsStatus: string;
  eta: string;
}

const MODE_ICON: Record<string, string> = {
  Sea: "🚢",
  Air: "✈️",
  Land: "🚛",
};

function shortPort(p: string) {
  const first = p.split(",")[0];
  return first.length > 26 ? `${first.slice(0, 25)}…` : first;
}

function statusTone(status: string) {
  const s = status.toLowerCase();
  if (s.includes("deliver")) return "text-lime border-lime/30 bg-lime/10";
  if (s.includes("customs")) return "text-amber border-amber/30 bg-amber/10";
  if (s.includes("transit") || s.includes("depart") || s.includes("loaded"))
    return "text-signal border-signal/30 bg-signal/10";
  return "text-mist border-white/10 bg-white/5";
}

export function LiveBoard({ rows }: { rows: BoardRow[] }) {
  const [tick, setTick] = useState(0);
  const [highlight, setHighlight] = useState<string | null>(null);

  useEffect(() => {
    const id = setInterval(() => {
      setTick((t) => t + 1);
      const pick = rows[Math.floor(Math.random() * rows.length)];
      if (pick) {
        setHighlight(pick.trackingNumber);
        setTimeout(() => setHighlight(null), 1600);
      }
    }, 4200);
    return () => clearInterval(id);
  }, [rows]);

  const clock = new Date();

  return (
    <div className="relative overflow-hidden rounded-[28px] border border-white/[0.08] bg-ink-2/80 backdrop-blur-xl">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-lime/60 to-transparent" />

      {/* header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.07] px-5 py-4">
        <div className="flex items-center gap-3">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full rounded-full bg-lime opacity-70 gt-pulse" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-lime" />
          </span>
          <h3 className="font-display text-sm font-bold uppercase tracking-[0.16em] text-bone">
            Live Trade Board
          </h3>
        </div>
        <div className="font-mono-gt flex items-center gap-4 text-[10px] uppercase tracking-[0.2em] text-mist">
          <span className="tabular-nums">
            {clock.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" })} UTC
          </span>
          <span className="text-lime tabular-nums">{rows.length} ACTIVE</span>
        </div>
      </div>

      {/* table */}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-left">
          <thead>
            <tr className="font-mono-gt border-b border-white/[0.06] text-[9px] uppercase tracking-[0.24em] text-mist">
              <th className="px-5 py-3 font-normal">Ref</th>
              <th className="px-3 py-3 font-normal">Mode</th>
              <th className="px-3 py-3 font-normal">Origin</th>
              <th className="px-3 py-3 font-normal">Destination</th>
              <th className="px-3 py-3 font-normal">Status</th>
              <th className="px-3 py-3 font-normal">Customs</th>
              <th className="px-5 py-3 text-right font-normal">ETA</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <motion.tr
                key={r.trackingNumber}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.07, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className="group relative border-b border-white/[0.04] text-[13px] transition-colors last:border-0 hover:bg-white/[0.03]"
              >
                <td className="px-5 py-3.5">
                  <Link
                    href="/tracking"
                    className="font-mono-gt text-[11px] tracking-tight text-lime underline-offset-4 hover:underline"
                  >
                    {r.trackingNumber}
                  </Link>
                </td>
                <td className="px-3 py-3.5">
                  <span className="text-base" aria-hidden>
                    {MODE_ICON[r.mode] ?? "📦"}
                  </span>
                </td>
                <td className="px-3 py-3.5 text-mist">{shortPort(r.originPort)}</td>
                <td className="px-3 py-3.5 text-bone">{shortPort(r.destinationPort)}</td>
                <td className="px-3 py-3.5">
                  <span
                    className={`inline-flex rounded-full border px-2.5 py-1 text-[10px] font-medium ${statusTone(r.status)}`}
                  >
                    {r.status}
                  </span>
                </td>
                <td className="px-3 py-3.5 font-mono-gt text-[10px] uppercase tracking-[0.1em] text-mist">
                  {r.customsStatus}
                </td>
                <td className="px-5 py-3.5 text-right font-mono-gt text-[11px] tabular-nums text-mist">
                  {new Date(r.eta).toLocaleDateString("en-GB", { day: "2-digit", month: "short" })}
                </td>

                <AnimatePresence>
                  {highlight === r.trackingNumber && (
                    <motion.span
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="pointer-events-none absolute inset-0 bg-lime/[0.06]"
                    />
                  )}
                </AnimatePresence>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* footer scanline */}
      <div className="relative h-8 overflow-hidden border-t border-white/[0.07]">
        <div className="absolute inset-x-0 h-8 gt-shimmer opacity-40" />
        <p className="font-mono-gt relative flex h-full items-center justify-between px-5 text-[9px] uppercase tracking-[0.24em] text-mist">
          <span>Refresh cycle {String(tick).padStart(4, "0")}</span>
          <span className="text-lime">● Streaming</span>
        </p>
      </div>
    </div>
  );
}
