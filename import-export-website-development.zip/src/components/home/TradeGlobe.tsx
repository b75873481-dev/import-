"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

const hubs = [
  { id: "rtm", label: "ROTTERDAM", x: 176, y: 168, code: "NLRTM" },
  { id: "sgp", label: "SINGAPORE", x: 322, y: 292, code: "SGSIN" },
  { id: "lax", label: "LONG BEACH", x: 66, y: 214, code: "USLGB" },
  { id: "dxb", label: "JEBEL ALI", x: 268, y: 244, code: "AEJEA" },
  { id: "sha", label: "SHANGHAI", x: 350, y: 216, code: "CNSHA" },
  { id: "scl", label: "SANTOS", x: 132, y: 330, code: "BRSSZ" },
];

const lanes: [number, number][] = [
  [2, 4],
  [4, 1],
  [1, 3],
  [3, 0],
  [0, 2],
  [5, 0],
  [4, 0],
  [1, 5],
];

function arc(a: { x: number; y: number }, b: { x: number; y: number }) {
  const mx = (a.x + b.x) / 2;
  const my = (a.y + b.y) / 2;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len = Math.hypot(dx, dy);
  const nx = -dy / (len || 1);
  const ny = dx / (len || 1);
  const bow = Math.min(58, len * 0.28);
  return `M ${a.x} ${a.y} Q ${mx + nx * bow} ${my + ny * bow} ${b.x} ${b.y}`;
}

export function TradeGlobe() {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const rotate = useTransform(scrollYProgress, [0, 1], reduce ? [0, 0] : [-9, 9]);
  const ty = useTransform(scrollYProgress, [0, 1], reduce ? [0, 0] : [40, -40]);

  return (
    <div ref={ref} className="relative aspect-[4/3] w-full">
      <motion.div style={{ rotate: rotate, y: ty }} className="absolute inset-0">
        <svg viewBox="0 0 440 400" className="h-full w-full overflow-visible">
          <defs>
            <radialGradient id="globeGlow" cx="38%" cy="34%" r="72%">
              <stop offset="0%" stopColor="#1b2430" stopOpacity="0.95" />
              <stop offset="60%" stopColor="#0d1117" stopOpacity="0.75" />
              <stop offset="100%" stopColor="#07080b" stopOpacity="0.2" />
            </radialGradient>
            <linearGradient id="laneGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#c8ff3e" stopOpacity="0.95" />
              <stop offset="100%" stopColor="#4ea8ff" stopOpacity="0.55" />
            </linearGradient>
            <filter id="soft" x="-60%" y="-60%" width="220%" height="220%">
              <feGaussianBlur stdDeviation="5" result="b" />
              <feMerge>
                <feMergeNode in="b" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* wireframe globe */}
          <g transform="translate(220 200)">
            <circle r="168" fill="url(#globeGlow)" />
            <circle r="168" fill="none" stroke="rgba(200,255,62,0.22)" strokeWidth="1" />
            <circle r="168" fill="none" stroke="rgba(200,255,62,0.5)" strokeWidth="0.4" strokeDasharray="2 7" />

            {/* latitudes */}
            {[-126, -84, -42, 0, 42, 84, 126].map((y, i) => (
              <ellipse
                key={i}
                cx="0"
                cy={y}
                rx={Math.sqrt(Math.max(0, 168 * 168 - y * y))}
                ry={Math.max(6, Math.abs(y) === 0 ? 26 : 26 * Math.cos((y / 168) * 1.1))}
                fill="none"
                stroke="rgba(237,238,240,0.09)"
                strokeWidth="0.9"
              />
            ))}

            {/* longitudes — spinning */}
            <motion.g
              animate={reduce ? undefined : { rotateY: 360 }}
              transition={{ duration: 38, repeat: Infinity, ease: "linear" }}
              style={{ transformOrigin: "0px 0px", transformStyle: "preserve-3d" }}
            >
              {[0, 30, 60, 90, 120, 150].map((deg) => (
                <ellipse
                  key={deg}
                  cx="0"
                  cy="0"
                  rx={Math.abs(168 * Math.cos((deg * Math.PI) / 180))}
                  ry="168"
                  fill="none"
                  stroke="rgba(237,238,240,0.08)"
                  strokeWidth="0.9"
                  transform={`rotate(${deg})`}
                />
              ))}
            </motion.g>

            {/* scan sweep */}
            <motion.g
              animate={reduce ? undefined : { rotate: 360 }}
              transition={{ duration: 14, repeat: Infinity, ease: "linear" }}
              style={{ transformOrigin: "0px 0px" }}
            >
              <path
                d="M0 0 L168 0 A168 168 0 0 0 118.8 -118.8 Z"
                fill="rgba(200,255,62,0.06)"
              />
            </motion.g>
          </g>

          {/* trade lanes */}
          <g>
            {lanes.map(([ai, bi], i) => (
              <path
                key={i}
                d={arc(hubs[ai], hubs[bi])}
                fill="none"
                stroke="url(#laneGrad)"
                strokeWidth="1.1"
                opacity="0.5"
                className="gt-dash"
                style={{ animationDelay: `${i * -2.4}s` }}
              />
            ))}
          </g>

          {/* moving cargo dots */}
          {!reduce &&
            lanes.map(([ai, bi], i) => (
              <circle key={`d${i}`} r="2.6" fill="#c8ff3e" filter="url(#soft)">
                <animateMotion
                  dur={`${7 + (i % 4) * 2.2}s`}
                  repeatCount="indefinite"
                  path={arc(hubs[ai], hubs[bi])}
                  begin={`${i * 0.9}s`}
                />
              </circle>
            ))}

          {/* hub nodes */}
          {hubs.map((h, i) => (
            <g key={h.id} transform={`translate(${h.x} ${h.y})`}>
              {!reduce && (
                <circle
                  r="6"
                  fill="none"
                  stroke="#c8ff3e"
                  strokeWidth="1"
                  className="gt-pulse"
                  style={{ animationDelay: `${i * 0.4}s`, transformOrigin: "center" }}
                />
              )}
              <circle r="3.4" fill="#c8ff3e" />
              <circle r="7" fill="none" stroke="rgba(200,255,62,0.35)" strokeWidth="0.8" />
              <text
                x="12"
                y="-3"
                className="font-mono-gt"
                fill="#edeef0"
                fontSize="9"
                letterSpacing="1.6"
                fontWeight="600"
              >
                {h.label}
              </text>
              <text x="12" y="8" className="font-mono-gt" fill="#8b93a3" fontSize="7.5" letterSpacing="1.2">
                {h.code}
              </text>
            </g>
          ))}
        </svg>
      </motion.div>

      {/* corner HUD */}
      <div className="pointer-events-none absolute left-0 top-0 font-mono-gt text-[9px] uppercase tracking-[0.3em] text-mist">
        <div className="flex items-center gap-2">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime gt-blink" />
          Live network · 62 countries
        </div>
      </div>
      <div className="pointer-events-none absolute bottom-0 right-0 font-mono-gt text-[9px] uppercase tracking-[0.3em] text-mist">
        Sync {new Date().getFullYear()}
      </div>
    </div>
  );
}
