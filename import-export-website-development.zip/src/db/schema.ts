import {
  pgTable,
  serial,
  varchar,
  text,
  numeric,
  boolean,
  timestamp,
  integer,
  jsonb,
} from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  name: varchar("name", { length: 200 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  shortDescription: text("short_description").notNull(),
  description: text("description").notNull(),
  price: numeric("price", { precision: 12, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).notNull().default("USD"),
  unit: varchar("unit", { length: 60 }).notNull().default("unit"),
  minOrderQuantity: varchar("min_order_quantity", { length: 60 }).notNull().default("1 unit"),
  originCountry: varchar("origin_country", { length: 100 }).notNull(),
  imageUrl: varchar("image_url", { length: 500 }).notNull(),
  certifications: text("certifications").array().notNull().default([]),
  stockStatus: varchar("stock_status", { length: 40 }).notNull().default("In Stock"),
  leadTime: varchar("lead_time", { length: 60 }).notNull().default("7-14 days"),
  featured: boolean("featured").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const shipments = pgTable("shipments", {
  id: serial("id").primaryKey(),
  trackingNumber: varchar("tracking_number", { length: 40 }).notNull().unique(),
  status: varchar("status", { length: 60 }).notNull(),
  mode: varchar("mode", { length: 20 }).notNull().default("Sea"),
  originPort: varchar("origin_port", { length: 120 }).notNull(),
  destinationPort: varchar("destination_port", { length: 120 }).notNull(),
  customerName: varchar("customer_name", { length: 160 }).notNull(),
  productSummary: varchar("product_summary", { length: 200 }).notNull(),
  customsStatus: varchar("customs_status", { length: 60 }).notNull().default("Pending Review"),
  eta: timestamp("eta").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const shipmentEvents = pgTable("shipment_events", {
  id: serial("id").primaryKey(),
  shipmentId: integer("shipment_id")
    .notNull()
    .references(() => shipments.id, { onDelete: "cascade" }),
  status: varchar("status", { length: 80 }).notNull(),
  location: varchar("location", { length: 160 }).notNull(),
  note: text("note"),
  occurredAt: timestamp("occurred_at").notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: varchar("order_number", { length: 40 }).notNull().unique(),
  customerName: varchar("customer_name", { length: 160 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  company: varchar("company", { length: 160 }),
  items: jsonb("items").notNull(),
  subtotal: numeric("subtotal", { precision: 12, scale: 2 }).notNull(),
  total: numeric("total", { precision: 12, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).notNull().default("USD"),
  paymentMethod: varchar("payment_method", { length: 60 }).notNull(),
  paymentStatus: varchar("payment_status", { length: 40 }).notNull().default("paid"),
  shippingAddress: text("shipping_address").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  company: varchar("company", { length: 160 }),
  subject: varchar("subject", { length: 200 }).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const newsletterSubscribers = pgTable("newsletter_subscribers", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 200 }).notNull().unique(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
