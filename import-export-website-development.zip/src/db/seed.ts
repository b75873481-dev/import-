import "dotenv/config";
import { db, pool } from "./index";
import { products, shipments, shipmentEvents } from "./schema";

async function seed() {
  console.log("Seeding database...");

  await db.delete(shipmentEvents);
  await db.delete(shipments);
  await db.delete(products);

  const insertedProducts = await db
    .insert(products)
    .values([
      {
        slug: "arabica-green-coffee-beans",
        name: "Premium Arabica Green Coffee Beans",
        category: "Food & Beverage",
        shortDescription: "Grade-1 washed arabica beans sourced from high-altitude estates.",
        description:
          "Our Grade-1 washed Arabica green coffee beans are cultivated at altitudes above 1,500m, hand-picked and wet-processed for a clean, bright cup profile. Each lot is moisture-tested, screened for defects, and packed in GrainPro liners inside jute bags to preserve freshness during ocean transit. Ideal for specialty roasters seeking consistent, traceable supply.",
        price: "4.85",
        currency: "USD",
        unit: "per kg",
        minOrderQuantity: "1 x 20ft container (18,000 kg)",
        originCountry: "Colombia",
        imageUrl: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=1200&q=80",
        certifications: ["ISO 22000", "Fair Trade", "Organic", "FDA Registered"],
        stockStatus: "In Stock",
        leadTime: "12-18 days",
        featured: true,
      },
      {
        slug: "extra-virgin-olive-oil",
        name: "Cold-Pressed Extra Virgin Olive Oil",
        category: "Food & Beverage",
        shortDescription: "First cold-press EVOO, low acidity, bottled or bulk flexi-tank.",
        description:
          "Produced from early-harvest olives and cold-pressed within hours of picking to retain polyphenols and a low (<0.3%) acidity level. Available in bulk flexi-tanks, stainless totes, or private-label glass bottles. Every batch ships with a certificate of analysis and organoleptic panel test results.",
        price: "6.20",
        currency: "USD",
        unit: "per liter",
        minOrderQuantity: "1,000 liters",
        originCountry: "Spain",
        imageUrl: "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=1200&q=80",
        certifications: ["CE Marked", "ISO 22000", "Kosher", "Halal"],
        stockStatus: "In Stock",
        leadTime: "10-15 days",
        featured: true,
      },
      {
        slug: "industrial-grade-steel-coils",
        name: "Hot-Rolled Steel Coils (Industrial Grade)",
        category: "Industrial & Raw Materials",
        shortDescription: "ASTM A36 hot-rolled steel coils for construction & manufacturing.",
        description:
          "Hot-rolled steel coils manufactured to ASTM A36 / EN 10025 specifications, suitable for structural fabrication, automotive, and heavy manufacturing applications. Thickness ranges from 2mm to 20mm with mill test certificates (MTC 3.1) provided for every shipment. Available in standard coil widths with custom slitting on request.",
        price: "780.00",
        currency: "USD",
        unit: "per metric ton",
        minOrderQuantity: "25 metric tons",
        originCountry: "South Korea",
        imageUrl: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?w=1200&q=80",
        certifications: ["ISO 9001", "CE Marked", "ASTM Certified"],
        stockStatus: "Limited Stock",
        leadTime: "20-30 days",
        featured: true,
      },
      {
        slug: "disposable-nitrile-gloves",
        name: "Medical-Grade Nitrile Examination Gloves",
        category: "Medical & Healthcare",
        shortDescription: "Powder-free nitrile gloves, FDA 510(k) cleared, CE certified.",
        description:
          "Powder-free nitrile examination gloves manufactured under ISO 13485 quality systems. FDA 510(k) cleared and CE marked under MDR 2017/745 for medical device compliance. AQL 1.5 tested for pinholes, with high tensile strength and chemical splash resistance. Packed 100 pcs/box, 10 boxes/carton.",
        price: "0.045",
        currency: "USD",
        unit: "per piece",
        minOrderQuantity: "1,000,000 pieces",
        originCountry: "Malaysia",
        imageUrl: "https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=1200&q=80",
        certifications: ["FDA 510(k)", "CE MDR", "ISO 13485"],
        stockStatus: "In Stock",
        leadTime: "15-25 days",
        featured: true,
      },
      {
        slug: "solar-photovoltaic-panels",
        name: "Monocrystalline Solar PV Panels 550W",
        category: "Energy & Electronics",
        shortDescription: "High-efficiency 550W mono PERC panels, 25-year warranty.",
        description:
          "High-efficiency monocrystalline PERC solar panels rated at 550W with up to 21.3% module efficiency. Built with anti-reflective tempered glass and a corrosion-resistant anodized aluminum frame rated for extreme weather. Backed by a 12-year product and 25-year linear power output warranty, tested to IEC 61215 and IEC 61730 standards.",
        price: "142.00",
        currency: "USD",
        unit: "per panel",
        minOrderQuantity: "500 panels",
        originCountry: "Vietnam",
        imageUrl: "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=1200&q=80",
        certifications: ["IEC 61215", "CE Marked", "ISO 9001", "TUV Certified"],
        stockStatus: "In Stock",
        leadTime: "25-35 days",
        featured: false,
      },
      {
        slug: "organic-cotton-textiles",
        name: "GOTS-Certified Organic Cotton Fabric",
        category: "Textiles & Apparel",
        shortDescription: "GOTS-certified organic cotton, OEKO-TEX, woven & knit rolls.",
        description:
          "100% GOTS-certified organic cotton fabric available in woven and knit constructions, pre-shrunk and ready for cut-and-sew. Full chain-of-custody traceability from ginning to finishing, with OEKO-TEX Standard 100 certification confirming freedom from harmful substances. Custom GSM, width, and dyeing available for private label apparel brands.",
        price: "3.10",
        currency: "USD",
        unit: "per meter",
        minOrderQuantity: "5,000 meters",
        originCountry: "India",
        imageUrl: "https://images.unsplash.com/photo-1605518216938-7c31b7b14ad0?w=1200&q=80",
        certifications: ["GOTS", "OEKO-TEX", "ISO 14001"],
        stockStatus: "In Stock",
        leadTime: "18-28 days",
        featured: false,
      },
      {
        slug: "frozen-pacific-whiteleg-shrimp",
        name: "Frozen Pacific Whiteleg Shrimp (IQF)",
        category: "Food & Beverage",
        shortDescription: "IQF whiteleg shrimp, HACCP processed, cold-chain verified.",
        description:
          "Individually quick-frozen (IQF) whiteleg shrimp processed under HACCP and BRCGS Food Safety protocols. Harvested from certified sustainable farms, graded by count-per-kg, and blast-frozen within hours of harvest to preserve texture. Full cold-chain documentation and health certificates included for customs clearance.",
        price: "9.40",
        currency: "USD",
        unit: "per kg",
        minOrderQuantity: "20,000 kg",
        originCountry: "Ecuador",
        imageUrl: "https://images.pexels.com/photos/14062139/pexels-photo-14062139.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        certifications: ["HACCP", "BRCGS", "FDA Registered", "ASC Certified"],
        stockStatus: "Limited Stock",
        leadTime: "14-21 days",
        featured: false,
      },
      {
        slug: "cnc-precision-machine-parts",
        name: "CNC-Machined Precision Aluminum Parts",
        category: "Industrial & Raw Materials",
        shortDescription: "Tight-tolerance aluminum components for OEM assembly lines.",
        description:
          "Precision CNC-machined aluminum components manufactured to +/-0.01mm tolerances for OEM assembly integration. Produced under an IATF 16949 certified quality system with full dimensional inspection reports (CMM) included. Surface finishing options include anodizing, powder coating, and passivation.",
        price: "12.75",
        currency: "USD",
        unit: "per piece",
        minOrderQuantity: "2,000 pieces",
        originCountry: "China",
        imageUrl: "https://images.pexels.com/photos/28752153/pexels-photo-28752153.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        certifications: ["IATF 16949", "ISO 9001", "CE Marked"],
        stockStatus: "In Stock",
        leadTime: "20-30 days",
        featured: false,
      },
    ])
    .returning({ id: products.id, slug: products.slug });

  const now = Date.now();
  const day = 24 * 60 * 60 * 1000;

  const shipmentSeeds = [
    {
      trackingNumber: "UC-2026-100245",
      status: "In Transit - Ocean Freight",
      mode: "Sea",
      originPort: "Port of Buenaventura, Colombia",
      destinationPort: "Port of Rotterdam, Netherlands",
      customerName: "Nordic Roasters B.V.",
      productSummary: "Premium Arabica Green Coffee Beans - 1x40ft container",
      customsStatus: "Export Cleared",
      eta: new Date(now + 9 * day),
      events: [
        { status: "Order Confirmed", location: "Bogotá, Colombia", note: "Purchase order and commercial invoice generated.", offset: -14 },
        { status: "Export Customs Cleared", location: "Buenaventura, Colombia", note: "Export declaration approved, phytosanitary certificate issued.", offset: -11 },
        { status: "Loaded on Vessel", location: "Port of Buenaventura", note: "Container loaded on MV Pacific Trader, voyage PT-114E.", offset: -10 },
        { status: "In Transit - Ocean Freight", location: "Atlantic Ocean", note: "Vessel on schedule, next port call Panama Canal.", offset: -2 },
      ],
    },
    {
      trackingNumber: "UC-2026-100312",
      status: "Customs Clearance - Destination",
      mode: "Air",
      originPort: "Kuala Lumpur International Airport, Malaysia",
      destinationPort: "John F. Kennedy Airport, USA",
      customerName: "MedSupply Partners LLC",
      productSummary: "Medical-Grade Nitrile Examination Gloves - 12,000 cartons",
      customsStatus: "FDA Document Review",
      eta: new Date(now + 1 * day),
      events: [
        { status: "Order Confirmed", location: "Kuala Lumpur, Malaysia", note: "FDA 510(k) documentation attached to shipment file.", offset: -6 },
        { status: "Export Customs Cleared", location: "Kuala Lumpur International Airport", note: "Export permit validated.", offset: -4 },
        { status: "Departed Origin", location: "Kuala Lumpur International Airport", note: "Flight MH-019 departed on schedule.", offset: -3 },
        { status: "Arrived Destination Hub", location: "JFK Airport, USA", note: "Awaiting FDA prior notice confirmation.", offset: -1 },
        { status: "Customs Clearance - Destination", location: "JFK Airport, USA", note: "Entry documents under CBP/FDA review.", offset: 0 },
      ],
    },
    {
      trackingNumber: "UC-2026-100378",
      status: "Delivered",
      mode: "Sea",
      originPort: "Port of Busan, South Korea",
      destinationPort: "Port of Long Beach, USA",
      customerName: "Apex Structural Steel Inc.",
      productSummary: "Hot-Rolled Steel Coils - 500 metric tons",
      customsStatus: "Cleared & Released",
      eta: new Date(now - 2 * day),
      events: [
        { status: "Order Confirmed", location: "Busan, South Korea", note: "Mill test certificates issued.", offset: -28 },
        { status: "Export Customs Cleared", location: "Port of Busan", note: "Export declaration completed.", offset: -25 },
        { status: "Loaded on Vessel", location: "Port of Busan", note: "Loaded aboard MV Han River, voyage HR-048W.", offset: -24 },
        { status: "In Transit - Ocean Freight", location: "Pacific Ocean", note: "Vessel transiting on schedule.", offset: -12 },
        { status: "Arrived Destination Port", location: "Port of Long Beach", note: "Vessel berthed, discharge in progress.", offset: -4 },
        { status: "Customs Clearance - Destination", location: "Port of Long Beach", note: "CBP entry filed and cleared.", offset: -3 },
        { status: "Delivered", location: "Apex Structural Steel Inc. Warehouse, CA", note: "Proof of delivery signed.", offset: -2 },
      ],
    },
    {
      trackingNumber: "UC-2026-100421",
      status: "Order Processed",
      mode: "Sea",
      originPort: "Port of Valencia, Spain",
      destinationPort: "Port of Santos, Brazil",
      customerName: "Sabor Mediterraneo Importadora",
      productSummary: "Cold-Pressed Extra Virgin Olive Oil - 8,000 liters",
      customsStatus: "Pending Export Filing",
      eta: new Date(now + 21 * day),
      events: [
        { status: "Order Confirmed", location: "Valencia, Spain", note: "Production and packing in progress.", offset: -1 },
      ],
    },
    {
      trackingNumber: "UC-2026-100456",
      status: "In Transit - Road Freight",
      mode: "Land",
      originPort: "Tiruppur, India",
      destinationPort: "Hamburg, Germany",
      customerName: "EuroTextile GmbH",
      productSummary: "GOTS-Certified Organic Cotton Fabric - 15,000 meters",
      customsStatus: "Export Cleared",
      eta: new Date(now + 5 * day),
      events: [
        { status: "Order Confirmed", location: "Tiruppur, India", note: "GOTS certificate attached to shipment.", offset: -9 },
        { status: "Export Customs Cleared", location: "Nhava Sheva Port, India", note: "Export declaration approved.", offset: -7 },
        { status: "Loaded on Vessel", location: "Nhava Sheva Port", note: "Loaded aboard MV Euro Link.", offset: -6 },
        { status: "In Transit - Ocean Freight", location: "Arabian Sea", note: "Transiting toward Suez Canal.", offset: -3 },
        { status: "In Transit - Road Freight", location: "Rotterdam to Hamburg corridor", note: "Final-mile trucking in progress.", offset: 0 },
      ],
    },
  ];

  for (const s of shipmentSeeds) {
    const [inserted] = await db
      .insert(shipments)
      .values({
        trackingNumber: s.trackingNumber,
        status: s.status,
        mode: s.mode,
        originPort: s.originPort,
        destinationPort: s.destinationPort,
        customerName: s.customerName,
        productSummary: s.productSummary,
        customsStatus: s.customsStatus,
        eta: s.eta,
      })
      .returning({ id: shipments.id });

    await db.insert(shipmentEvents).values(
      s.events.map((e) => ({
        shipmentId: inserted.id,
        status: e.status,
        location: e.location,
        note: e.note,
        occurredAt: new Date(now + e.offset * day),
      }))
    );
  }

  console.log(`Seeded ${insertedProducts.length} products and ${shipmentSeeds.length} shipments.`);
  await pool.end();
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
